INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('147b1ba2048446459ef8da599b6a9a1d', 'kesplus_perm_1001', 0, '0', 'kesplus_app', '{ "zh-CN" : "权限点编码已经存在", "en-US" : "Permission point code already exists" }', -20998);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('899fe169a9584f1ca4fc68fbd8a54a72', 'kesplus_perm_1004', 0, '0', 'kesplus_app', '{ "zh-CN" : "只能删除分类下的权限点数据", "en-US" : "Can only delete permission point data under the category" }', -20998);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('c890056eee48426eb62cd4c8c63f5e14', 'kesplus_restful_1008', 0, '0', 'kesplus_app', '{ "zh-CN" : "未设置权限点", "en-US" : "Permission point not set" }', -20998);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('45fff0f012ea4257b1b28377bb9dea63', 'kesplus_restful_1016', 0, '0', 'kesplus_app', '{ "zh-CN" : "传入权限点参数为空", "en-US" : "Passed permission point parameter is empty" }', -20998);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('599dd20d235b48b392990dcbc2ca537a', 'kesplus_directory_1000', 0, '0', 'kesplus_app', '{ "zh-CN" : "目录类型不存在", "en-US" : "The directory type does not exist." }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('11e865caf6e7465e82fb12ddafb5c0a2', 'kesplus_package_1001', 0, '0', 'kesplus_app', '{ "zh-CN" : "同一层级包对象和包目录名称不能重复", "en-US" : "Package name cannot be same to directory name." }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('e930fdaea4c7488bbee41d056da94b2e', 'kesplus_package_1002', 0, '0', 'kesplus_app', '{ "zh-CN" : "包名已存在", "en-US" : "Package name exists." }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('950da8f885284a718b6d4807c7a8b27b', 'kesplus_perm_1000', 0, '0', 'kesplus_app', '{ "zh-CN" : "数据不能为空", "en-US" : "Data cannot be empty" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('f99be2eecfcc434796c156c48d3d0fa2', 'kesplus_perm_1002', 0, '0', 'kesplus_app', '{ "zh-CN" : "请选择删除数据", "en-US" : "Please select the data to delete" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('bd1437d1ec88416f8a49c3c628fb9d04', 'kesplus_perm_1003', 0, '0', 'kesplus_app', '{ "zh-CN" : "查询参数不能为空", "en-US" : "Query parameters cannot be empty" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('390c81a02080421db987d3a3085af86f', 'kesplus_restful_1007', 0, '0', 'kesplus_app', '{ "zh-CN" : "不支持的类型", "en-US" : "Unsupported type" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('4c97e5de4a6a4ac5b00ab3568980f6bc', 'kesplus_restful_1009', 0, '0', 'kesplus_app', '{ "zh-CN" : "RESTful不存在", "en-US" : "RESTful does not exist" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('3136a8082f284f7ba011ac8045bfc93c', 'kesplus_restful_1010', 0, '0', 'kesplus_app', '{ "zh-CN" : "系统api不允许删除", "en-US" : "System API deletion is not allowed" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('ace31d60f68748368c7c4b1c9146d76f', 'kesplus_restful_1011', 0, '0', 'kesplus_app', '{ "zh-CN" : "ID不能为空", "en-US" : "ID cannot be empty" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('2a04861a622b4aa0b99880c668f77517', 'kesplus_restful_1012', 0, '0', 'kesplus_app', '{ "zh-CN" : "名称不能为空", "en-US" : "Name cannot be empty" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('cb140c3df0f74af0a961afaaa2383674', 'kesplus_restful_1013', 0, '0', 'kesplus_app', '{ "zh-CN" : "错误的树结构", "en-US" : "Incorrect tree structure" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('703431626c2b47bfa8c4a7b6a15e54cf', 'kesplus_restful_1014', 0, '0', 'kesplus_app', '{ "zh-CN" : "视图id不存在", "en-US" : "View ID does not exist" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('dfdb43a0980c4c6786509c017c5759c9', 'kesplus_restful_1015', 0, '0', 'kesplus_app', '{ "zh-CN" : "函数/存储过程id不存在", "en-US" : "Function/Procedure ID does not exist" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('45ca7f1de23c4d27bba4dcb06c061bc7', 'kesplus_restful_1017', 0, '0', 'kesplus_app', '{ "zh-CN" : "该编号[%]已存在", "en-US" : "The number [%] already exists" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('42cc9a42feb64bc0904dd2f29bf62fa8', 'kesplus_restful_1018', 0, '0', 'kesplus_app', '{ "zh-CN" : "URL路径[%]已存在,请修改！", "en-US" : "The URL [%] path already exists,please modify." }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('d434a9d4920b4b5b91d8c24371e88710', 'kesplus_restful_1019', 0, '0', 'kesplus_app', '{ "zh-CN" : "RESTFul名称[%]已存在,请修改！", "en-US" : "The Title [%] already exists,please modify." }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('db1499cf302a45b09ff7f6567ba1367c', 'kesplus_route_1000', 0, '0', 'kesplus_app', '{ "zh-CN" : "该服务已被使用", "en-US" : "This service is already in use." }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('db1499cf302a4aa09ff7f6567ba1367c', 'kesplus_package_already_init', 0, '0', 'kesplus_app', '{ "zh-CN" : "当前模块下存在同名包[%]", "en-US" : "the package [%] is already in current module." }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('db1499cf302a4bb09ff7f6567ba1367c', 'kesplus_menu_already_init', 0, '0', 'kesplus_app', '{ "zh-CN" : "当前模块下存在同名菜单[%]", "en-US" : "the menu [%] is already in current module." }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('db1499cf302a4bbbbff7f6567ba1367c', 'kesplus_illegal_character_init', 0, '0', 'kesplus_app', '{ "zh-CN" : "菜单名称含有非法字符", "en-US" : "illegal character in the menu name." }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES ('db1499cf302a4bbbcff7f6567ba1367c','kesplus_permission_dir_already_init',0,'0','kesplus_app','{ "zh-CN" : "当前模块下存在同名权限点目录[%]", "en-US" : "the permission dir [%] is already in current module." }', -20998);




INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES ('db1499cf302a4bbbbff7f6bbaba13671','kesplus_menu_permission_name_exist',0,'0','kesplus_app','{ "zh-CN" : "关联生成的权限点/目录名称不能重复", "en-US" : "permission/dir name exists." }', -20998);
INSERT INTO kesplus_platform.kesplus_sys_i18n
VALUES ('db1499cf302a4bbbbff7f6bbaba13672','kesplus_permission_name_exist',0,'0','kesplus_app','{ "zh-CN" : "同一层级下，权限点/目录名称不能重复", "en-US" : "permission/dir name exists." }', -20998);
INSERT INTO kesplus_platform.kesplus_sys_i18n
VALUES ('db1499cf302a4bbbbff7f6bbaba13673','kesplus_permission_code_exist',0,'0','kesplus_app','{ "zh-CN" : "权限点编码不能重复", "en-US" : "permission code exists." }', -20998);
INSERT INTO kesplus_platform.kesplus_sys_i18n
VALUES ('db1499cf302a4bbbbff7f6bbaba13674','kesplus_permission_menu_name_exist',0,'0','kesplus_app','{ "zh-CN" : "权限点不能与菜单名称相同", "en-US" : "name of permission does not allowed be the same with the menu exists." }', -20998);
INSERT INTO kesplus_platform.kesplus_sys_i18n
VALUES ('db1499cf302a4bbbbff7f6bbaba13675','kesplus_rename_menu',0,'0','kesplus_app','{ "zh-CN" : "存在名称为[%]的菜单，请重新命名或修改该菜单名称", "en-US" : "permission/dir name [%] exists." }', -20998);
