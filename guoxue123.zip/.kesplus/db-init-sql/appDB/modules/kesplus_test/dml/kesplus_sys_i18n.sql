INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('b2e8bc0d1ad44d808eaa5dc88265a431', 'kesplus_autotest_1000', 0, '0', 'kesplus_test', '{ "zh-CN" : "计划ID不能为空", "en-US" : "Plan ID cannot be empty" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('80b823b54ec844dab61df21fa54fcfa8', 'kesplus_autotest_1001', 0, '0', 'kesplus_test', '{ "zh-CN" : "该计划已禁用", "en-US" : "The plan is disabled" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('c7d5ebc4d99e4f00989c82a9a6d5e673', 'kesplus_autotest_1002', 0, '0', 'kesplus_test', '{ "zh-CN" : "参数名称已存在", "en-US" : "The parameter name already exists." }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('b5e9bfc4501047dc85168c04d8d17f35', 'kesplus_autotest_1003', 0, '0', 'kesplus_test', '{ "zh-CN" : "请选择一个场景", "en-US" : "Please select a scene." }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('c852843de79d475ea161c2c87bb9625d', 'kesplus_autotest_1004', 0, '0', 'kesplus_test', '{ "zh-CN" : "请输入执行计划名称", "en-US" : "Please enter the execution plan name." }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('8f860b8525b1493ba73c8630381d5f46', 'kesplus_autotest_1005', 0, '0', 'kesplus_test', '{ "zh-CN" : "请选择计划类型", "en-US" : "Please select the plan type." }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('de82b668fbb04fc489fe4e24a372dd29', 'kesplus_autotest_1006', 0, '0', 'kesplus_test', '{ "zh-CN" : "请输入计划表达式", "en-US" : "Please enter the plan expression." }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('3f573aa5283b4f70b573bc924e2f432a', 'kesplus_autotest_1007', 0, '0', 'kesplus_test', '{ "zh-CN" : "名称不能为空", "en-US" : "The name cannot be empty." }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('1d63238d39f940939d9ad2eae10516a6', 'kesplus_autotest_1008', 0, '0', 'kesplus_test', '{ "zh-CN" : "名称已存在", "en-US" : "The name already exists." }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('0f346dc893794850a5209eeb93d6bedd', 'kesplus_autotest_1009', 0, '0', 'kesplus_test', '{ "zh-CN" : "用例ID不能为空", "en-US" : "The case ID cannot be empty." }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('1f5bc515b19043e1b1ab2ecbb1fd80b6', 'kesplus_autotest_1010', 0, '0', 'kesplus_test', '{ "zh-CN" : "请选择一个用例", "en-US" : "Please select a case." }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('7b85ad341ea84904b63b0c1fdaa09790', 'kesplus_autotest_1011', 0, '0', 'kesplus_test', '{ "zh-CN" : "当前目录下存在数据,不能删除", "en-US" : "Data exists in the current directory and cannot be deleted." }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('fef980e4ed65419b8d4953d17587f346', 'kesplus_autotest_1012', 0, '0', 'kesplus_test', '{ "zh-CN" : "名称不能为空", "en-US" : "The name cannot be empty." }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('4b74b83ee435485497fc2ef5544daa4f', 'kesplus_autotest_1013', 0, '0', 'kesplus_test', '{ "zh-CN" : "名称已存在", "en-US" : "The name already exists." }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('df4ab07e53524157a26ea2050bc217ab', 'kesplus_autotest_1014', 0, '0', 'kesplus_test', '{ "zh-CN" : "当前目录下存在数据,不能删除", "en-US" : "Data exists in the current directory and cannot be deleted." }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('ecbbef91a79b472ba706baa2c88bd84e', 'kesplus_autotest_1015', 0, '0', 'kesplus_test', '{ "zh-CN" : "场景ID不能为空", "en-US" : "The scene ID cannot be empty." }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('b3549f7ff0684093a305be2bab64f46a', 'kesplus_autotest_1016', 0, '0', 'kesplus_test', '{ "zh-CN" : "该场景已禁用", "en-US" : "This scenario is disabled" }', -20999);
