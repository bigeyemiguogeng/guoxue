INSERT INTO kesplus_base.kesplus_module_role_permission ("id","role_id","permission_id","create_by","create_time","update_by","update_time","dept_id","module_id") VALUES
	 ('3534cda258d055248d21bc1da42762f2','4fc4d87dcab3488cb3d7487a58928af2','3534cda258d055248d21bc1da42762f2','${currentUserId}',SYSDATE,'${currentUserId}',SYSDATE,'${currentDeptId}','dfb8894291c34ac28e3458bba277e0ff'),
	 ('3534cda258d055248d21bc1da42762d3','4fc4d87dcab3488cb3d7487a58928af2','3534cda258d055248d21bc1da42762d3','${currentUserId}',SYSDATE,'${currentUserId}',SYSDATE,'${currentDeptId}','dfb8894291c34ac28e3458bba277e0ff'),
	 ('3534cda258d055248d21bc1da42762n3','4fc4d87dcab3488cb3d7487a58928af2','3534cda258d055248d21bc1da42762n3','${currentUserId}',SYSDATE,'${currentUserId}',SYSDATE,'${currentDeptId}','dfb8894291c34ac28e3458bba277e0ff'),
	 ('3534cda258d055248d21bc1da42762n5','4fc4d87dcab3488cb3d7487a58928af2','3534cda258d055248d21bc1da42762n5','${currentUserId}',SYSDATE,'${currentUserId}',SYSDATE,'${currentDeptId}','dfb8894291c34ac28e3458bba277e0ff'),
	 ('3534cda258d055248d21bc1da42762n6','4fc4d87dcab3488cb3d7487a58928af2','3534cda258d055248d21bc1da42762n6','${currentUserId}',SYSDATE,'${currentUserId}',SYSDATE,'${currentDeptId}','dfb8894291c34ac28e3458bba277e0ff'),
	 ('3534cda258d055248d21bc1da42762n7','4fc4d87dcab3488cb3d7487a58928af2','3534cda258d055248d21bc1da42762n7','${currentUserId}',SYSDATE,'${currentUserId}',SYSDATE,'${currentDeptId}','dfb8894291c34ac28e3458bba277e0ff'),
	 ('3534cda258d055248d21bc1da42762n8','4fc4d87dcab3488cb3d7487a58928af2','3534cda258d055248d21bc1da42762n8','${currentUserId}',SYSDATE,'${currentUserId}',SYSDATE,'${currentDeptId}','dfb8894291c34ac28e3458bba277e0ff'),
	 ('3534cda258d055248d21bc1da42762n4','4fc4d87dcab3488cb3d7487a58928af2','3534cda258d055248d21bc1da42762n4','${currentUserId}',SYSDATE,'${currentUserId}',SYSDATE,'${currentDeptId}','dfb8894291c34ac28e3458bba277e0ff'),
	 ('3534cda258d055248d21bc1da42762m3','a5438851fa214cd49264ba9992925665','3534cda258d055248d21bc1da42762f2','${currentUserId}',SYSDATE,'${currentUserId}',SYSDATE,'${currentDeptId}','dfb8894291c34ac28e3458bba277e0ff'),
	 ('3534cda258d055248d21bc1da42762d4','a5438851fa214cd49264ba9992925665','3534cda258d055248d21bc1da42762d3','${currentUserId}',SYSDATE,'${currentUserId}',SYSDATE,'${currentDeptId}','dfb8894291c34ac28e3458bba277e0ff');

INSERT INTO kesplus_base.kesplus_module_role_permission ("id","role_id","permission_id","create_by","create_time","update_by","update_time","dept_id","module_id") VALUES
     ('3534cda258d055248d21bc1da42762m1','a5438851fa214cd49264ba9992925665','3534cda258d055248d21bc1da42762f2','${currentUserId}',SYSDATE,'${currentUserId}',SYSDATE,'${currentDeptId}','dfb8894291c34ac28e3458bba277e0ff'),
     ('3534cda258d055248d21bc1da42762m2','a5438851fa214cd49264ba9992925665','3534cda258d055248d21bc1da42762d3','${currentUserId}',SYSDATE,'${currentUserId}',SYSDATE,'${currentDeptId}','dfb8894291c34ac28e3458bba277e0ff'),
     ('3534cda258d055248d21bc1da42762l3','a5438851fa214cd49264ba9992925665','3534cda258d055248d21bc1da42762n3','${currentUserId}',SYSDATE,'${currentUserId}',SYSDATE,'${currentDeptId}','dfb8894291c34ac28e3458bba277e0ff'),
     ('3534cda258d055248d21bc1da42762k3','a5438851fa214cd49264ba9992925665','3534cda258d055248d21bc1da42762n5','${currentUserId}',SYSDATE,'${currentUserId}',SYSDATE,'${currentDeptId}','dfb8894291c34ac28e3458bba277e0ff'),
     ('3534cda258d055248d21bc1da42762k8','a5438851fa214cd49264ba9992925665','3534cda258d055248d21bc1da42762n6','${currentUserId}',SYSDATE,'${currentUserId}',SYSDATE,'${currentDeptId}','dfb8894291c34ac28e3458bba277e0ff'),
     ('3534cda258d055248d21bc1da42762y8','a5438851fa214cd49264ba9992925665','3534cda258d055248d21bc1da42762n7','${currentUserId}',SYSDATE,'${currentUserId}',SYSDATE,'${currentDeptId}','dfb8894291c34ac28e3458bba277e0ff'),
     ('3534cda258d055248d21bc1da42762zz','a5438851fa214cd49264ba9992925665','3534cda258d055248d21bc1da42762n8','${currentUserId}',SYSDATE,'${currentUserId}',SYSDATE,'${currentDeptId}','dfb8894291c34ac28e3458bba277e0ff'),
     ('3534cda258d055248d21bc1da42762l4','a5438851fa214cd49264ba9992925665','3534cda258d055248d21bc1da42762n4','${currentUserId}',SYSDATE,'${currentUserId}',SYSDATE,'${currentDeptId}','dfb8894291c34ac28e3458bba277e0ff'),
	 ('8a32931624d6445f9a32e1e611184208','a5438851fa214cd49264ba9992925665','3534cda258d055248d21bc1da42762f2','${currentUserId}',SYSDATE,'${currentUserId}',SYSDATE,'${currentDeptId}','dfb8894291c34ac28e3458bba277e0ff');


INSERT INTO kesplus_base.kesplus_module_role_permission ("id","role_id","permission_id","create_by","create_time","update_by","update_time","dept_id","module_id") VALUES
	 ('dc0025755e8047dd916dfeb5affe9d01','4fc4d87dcab3488cb3d7487a58928af2','dc0025755e8047dd916dfeb5affe9d01','${currentUserId}',SYSDATE,'${currentUserId}',SYSDATE,'${currentDeptId}','dfb8894291c34ac28e3458bba277e0ff'),
	 ('dc0025755e8047dd916dfeb5affe9d02','4fc4d87dcab3488cb3d7487a58928af2','dc0025755e8047dd916dfeb5affe9d02','${currentUserId}',SYSDATE,'${currentUserId}',SYSDATE,'${currentDeptId}','dfb8894291c34ac28e3458bba277e0ff');
INSERT INTO kesplus_base.kesplus_module_role_permission ("id","role_id","permission_id","create_by","create_time","update_by","update_time","dept_id","module_id") VALUES
	 ('dc0025755e8047dd916dfeb5affe9d08','4fc4d87dcab3488cb3d7487a58928af2','dc0025755e8047dd916dfeb5affe9d08','${currentUserId}',SYSDATE,'${currentUserId}',SYSDATE,'${currentDeptId}','dfb8894291c34ac28e3458bba277e0ff');
INSERT INTO kesplus_base.kesplus_module_role_permission ("id","role_id","permission_id","create_by","create_time","update_by","update_time","dept_id","module_id") VALUES
	 ('dc0025755e8047dd916dfeb5affe9d03','4fc4d87dcab3488cb3d7487a58928af2','dc0025755e8047dd916dfeb5affe9d03','${currentUserId}',SYSDATE,'${currentUserId}',SYSDATE,'${currentDeptId}','dfb8894291c34ac28e3458bba277e0ff'),
	 ('dc0025755e8047dd916dfeb5a62e9d04','4fc4d87dcab3488cb3d7487a58928af2','dc0025755e8047dd916dfeb5a62e9d04','${currentUserId}',SYSDATE,'${currentUserId}',SYSDATE,'${currentDeptId}','dfb8894291c34ac28e3458bba277e0ff'),
 	 ('dc0025755e8047dd916dfeb5a62e9d03','4fc4d87dcab3488cb3d7487a58928af2','dc0025755e8047dd916dfeb5a62e9d03','${currentUserId}',SYSDATE,'${currentUserId}',SYSDATE,'${currentDeptId}','dfb8894291c34ac28e3458bba277e0ff');
INSERT INTO kesplus_base.kesplus_module_role_permission ("id","role_id","permission_id","create_by","create_time","update_by","update_time","dept_id","module_id") VALUES
	 ('dc0025755e8047dd916dfeb5a62e9d07','4fc4d87dcab3488cb3d7487a58928af2','dc0025755e8047dd916dfeb5a62e9d04','${currentUserId}',SYSDATE,'${currentUserId}',SYSDATE,'${currentDeptId}','dfb8894291c34ac28e3458bba277e0ff'),
	 ('dc0025755e8047dd916dfeb5a62e9d01','4fc4d87dcab3488cb3d7487a58928af2','dc0025755e8047dd916dfeb5a62e9d01','${currentUserId}',SYSDATE,'${currentUserId}',SYSDATE,'${currentDeptId}','dfb8894291c34ac28e3458bba277e0ff'),
	 ('dc0025755e8047dd916dfeb5a62e9d02','4fc4d87dcab3488cb3d7487a58928af2','dc0025755e8047dd916dfeb5a62e9d02','${currentUserId}',SYSDATE,'${currentUserId}',SYSDATE,'${currentDeptId}','dfb8894291c34ac28e3458bba277e0ff'),
	 ('693eefdb5bcb4bf89ff00017bd35a001','4fc4d87dcab3488cb3d7487a58928af2','693eefdb5bcb4bf89ff00017bd35a001','${currentUserId}',SYSDATE,'${currentUserId}',SYSDATE,'${currentDeptId}','dfb8894291c34ac28e3458bba277e0ff'),
	 ('693eefdb5bcb4bf89ff00017bd35a014','4fc4d87dcab3488cb3d7487a58928af2','693eefdb5bcb4bf89ff00017bd35a014','${currentUserId}',SYSDATE,'${currentUserId}',SYSDATE,'${currentDeptId}','dfb8894291c34ac28e3458bba277e0ff'),
	 ('693eefdb5bcb4bf89ff00017bd35a013','4fc4d87dcab3488cb3d7487a58928af2','693eefdb5bcb4bf89ff00017bd35a013','${currentUserId}',SYSDATE,'${currentUserId}',SYSDATE,'${currentDeptId}','dfb8894291c34ac28e3458bba277e0ff');
INSERT INTO kesplus_base.kesplus_module_role_permission ("id","role_id","permission_id","create_by","create_time","update_by","update_time","dept_id","module_id") VALUES
	 ('693eefdb5bcb4bf89ff00017bd35a012','4fc4d87dcab3488cb3d7487a58928af2','693eefdb5bcb4bf89ff00017bd35a012','${currentUserId}',SYSDATE,'${currentUserId}',SYSDATE,'${currentDeptId}','dfb8894291c34ac28e3458bba277e0ff'),
	 ('693eefdb5bcb4bf89ff00017bd35a007','4fc4d87dcab3488cb3d7487a58928af2','693eefdb5bcb4bf89ff00017bd35a007','${currentUserId}',SYSDATE,'${currentUserId}',SYSDATE,'${currentDeptId}','dfb8894291c34ac28e3458bba277e0ff'),
	 ('eb2477991c2c4966b07debc7f9fba501','4fc4d87dcab3488cb3d7487a58928af2','eb2477991c2c4966b07debc7f9fba501','${currentUserId}',SYSDATE,'${currentUserId}',SYSDATE,'${currentDeptId}','dfb8894291c34ac28e3458bba277e0ff');
INSERT INTO kesplus_base.kesplus_module_role_permission ("id","role_id","permission_id","create_by","create_time","update_by","update_time","dept_id","module_id") VALUES
	 ('eb2477991c2c4966b07debc7f9fba502','4fc4d87dcab3488cb3d7487a58928af2','eb2477991c2c4966b07debc7f9fba502','${currentUserId}',SYSDATE,'${currentUserId}',SYSDATE,'${currentDeptId}','dfb8894291c34ac28e3458bba277e0ff'),
	 ('eb2477991c2c4966b07debc7f9fba503','4fc4d87dcab3488cb3d7487a58928af2','eb2477991c2c4966b07debc7f9fba503','${currentUserId}',SYSDATE,'${currentUserId}',SYSDATE,'${currentDeptId}','dfb8894291c34ac28e3458bba277e0ff'),
	 ('eb2477991c2c4966b07debc7f9fba507','4fc4d87dcab3488cb3d7487a58928af2','eb2477991c2c4966b07debc7f9fba507','${currentUserId}',SYSDATE,'${currentUserId}',SYSDATE,'${currentDeptId}','dfb8894291c34ac28e3458bba277e0ff');
INSERT INTO kesplus_base.kesplus_module_role_permission ("id","role_id","permission_id","create_by","create_time","update_by","update_time","dept_id","module_id") VALUES
	 ('3534cda258d055259d21bb5da4276206','4fc4d87dcab3488cb3d7487a58928af2','3534cda258d055259d21bb5da4276206','${currentUserId}',SYSDATE,'${currentUserId}',SYSDATE,'${currentDeptId}','dfb8894291c34ac28e3458bba277e0ff'),
	 ('3534cda258d055259d21bb5da4276201','4fc4d87dcab3488cb3d7487a58928af2','3534cda258d055259d21bb5da4276201','${currentUserId}',SYSDATE,'${currentUserId}',SYSDATE,'${currentDeptId}','dfb8894291c34ac28e3458bba277e0ff');
INSERT INTO kesplus_base.kesplus_module_role_permission ("id","role_id","permission_id","create_by","create_time","update_by","update_time","dept_id","module_id") VALUES
	 ('3534cda258d055259d21bb5da4276204','4fc4d87dcab3488cb3d7487a58928af2','3534cda258d055259d21bb5da4276204','${currentUserId}',SYSDATE,'${currentUserId}',SYSDATE,'${currentDeptId}','dfb8894291c34ac28e3458bba277e0ff'),
	 ('3534cda258d055259d21bb5da4276202','4fc4d87dcab3488cb3d7487a58928af2','3534cda258d055259d21bb5da4276202','${currentUserId}',SYSDATE,'${currentUserId}',SYSDATE,'${currentDeptId}','dfb8894291c34ac28e3458bba277e0ff'),
	 ('3534cda258d055259d21bb5da4276203','4fc4d87dcab3488cb3d7487a58928af2','3534cda258d055259d21bb5da4276203','${currentUserId}',SYSDATE,'${currentUserId}',SYSDATE,'${currentDeptId}','dfb8894291c34ac28e3458bba277e0ff'),
	 ('6bedfdf0669704e68b3df85e799f96b5','4fc4d87dcab3488cb3d7487a58928af2','6bedfdf0669704e68b3df85e799f96b5','${currentUserId}',SYSDATE,'${currentUserId}',SYSDATE,'${currentDeptId}','dfb8894291c34ac28e3458bba277e0ff'),
	 ('c1c1f86c5797d4c9aeab90268d6275d1','4fc4d87dcab3488cb3d7487a58928af2','c1c1f86c5797d4c9aeab90268d6275d1','${currentUserId}',SYSDATE,'${currentUserId}',SYSDATE,'${currentDeptId}','dfb8894291c34ac28e3458bba277e0ff');
INSERT INTO kesplus_base.kesplus_module_role_permission ("id","role_id","permission_id","create_by","create_time","update_by","update_time","dept_id","module_id") VALUES
	 ('8dd7622786904b8ab21f42ec60421c26','4fc4d87dcab3488cb3d7487a58928af2','8dd7622786904b8ab21f42ec60421c26','${currentUserId}',SYSDATE,'${currentUserId}',SYSDATE,'${currentDeptId}','dfb8894291c34ac28e3458bba277e0ff'),
	 ('f56d253ccd4264c6db29348abf1af2ff','4fc4d87dcab3488cb3d7487a58928af2','f56d253ccd4264c6db29348abf1af2ff','${currentUserId}',SYSDATE,'${currentUserId}',SYSDATE,'${currentDeptId}','dfb8894291c34ac28e3458bba277e0ff'),
	 ('725f289c94d94ece8bff4f6712c9df0e','4fc4d87dcab3488cb3d7487a58928af2','725f289c94d94ece8bff4f6712c9df0e','${currentUserId}',SYSDATE,'${currentUserId}',SYSDATE,'${currentDeptId}','dfb8894291c34ac28e3458bba277e0ff'),
	 ('dc0025755e8147dd91fffeb5affe9d03','4fc4d87dcab3488cb3d7487a58928af2','dc0025755e8147dd91fffeb5affe9d03','${currentUserId}',SYSDATE,'${currentUserId}',SYSDATE,'${currentDeptId}','dfb8894291c34ac28e3458bba277e0ff'),
	 ('dc0025755e8147dd91fffeb5affe9d01','4fc4d87dcab3488cb3d7487a58928af2','dc0025755e8147dd91fffeb5affe9d01','${currentUserId}',SYSDATE,'${currentUserId}',SYSDATE,'${currentDeptId}','dfb8894291c34ac28e3458bba277e0ff'),
	 ('861a96918258436fb8ec5adb64efbaa4','4fc4d87dcab3488cb3d7487a58928af2','861a96918258436fb8ec5adb64efbaa4','${currentUserId}',SYSDATE,'${currentUserId}',SYSDATE,'${currentDeptId}','dfb8894291c34ac28e3458bba277e0ff');
INSERT INTO kesplus_base.kesplus_module_role_permission ("id","role_id","permission_id","create_by","create_time","update_by","update_time","dept_id","module_id") VALUES
	 ('dc0025755e8147dd91fffeb5affe9d02','4fc4d87dcab3488cb3d7487a58928af2','dc0025755e8147dd91fffeb5affe9d02','${currentUserId}',SYSDATE,'${currentUserId}',SYSDATE,'${currentDeptId}','dfb8894291c34ac28e3458bba277e0ff'),
	 ('f9e844cca2da4a48a575eaa7834b9d6a','4fc4d87dcab3488cb3d7487a58928af2','f9e844cca2da4a48a575eaa7834b9d6a','${currentUserId}',SYSDATE,'${currentUserId}',SYSDATE,'${currentDeptId}','dfb8894291c34ac28e3458bba277e0ff'),
	 ('dc0025755e8147dd91fffeb5affe9d04','4fc4d87dcab3488cb3d7487a58928af2','dc0025755e8147dd91fffeb5affe9d04','${currentUserId}',SYSDATE,'${currentUserId}',SYSDATE,'${currentDeptId}','dfb8894291c34ac28e3458bba277e0ff'),
	 ('d7979be44d114f4faeb154bfd339e580','4fc4d87dcab3488cb3d7487a58928af2','d7979be44d114f4faeb154bfd339e580','${currentUserId}',SYSDATE,'${currentUserId}',SYSDATE,'${currentDeptId}','dfb8894291c34ac28e3458bba277e0ff');
INSERT INTO kesplus_base.kesplus_module_role_permission ("id","role_id","permission_id","create_by","create_time","update_by","update_time","dept_id","module_id") VALUES
	 ('3534cda258d055248d21bb5da42763f6','4fc4d87dcab3488cb3d7487a58928af2','f94168cbd2234761b72f3b7de135c909','${currentUserId}',SYSDATE,'${currentUserId}',SYSDATE,'${currentDeptId}','dfb8894291c34ac28e3458bba277e0ff');


INSERT INTO kesplus_base.kesplus_module_role_permission ("id","role_id","permission_id","create_by","create_time","update_by","update_time","dept_id","module_id") VALUES ('77b69d6f65d84e98b8d656b4ac42b685','a5438851fa214cd49264ba9992925665','4da11510fb614415bc7d3a3bf090d8b8','546508b9842c4e3698a1f2d3ae6fa917',SYSDATE,'546508b9842c4e3698a1f2d3ae6fa917',SYSDATE,NULL,'dfb8894291c34ac28e3458bba277e0ff');

INSERT INTO kesplus_base.kesplus_module_role_permission ("id","role_id","permission_id","create_by","create_time","update_by","update_time","dept_id","module_id") VALUES ('baf0b5bdee264787b0a9f971742eeb80','4fc4d87dcab3488cb3d7487a58928af2','dc0025755e8147dd92fffeb5affe9d13','546508b9842c4e3698a1f2d3ae6fa917',sysdate,'546508b9842c4e3698a1f2d3ae6fa917',sysdate,'0','dfb8894291c34ac28e3458bba277e0ff');

INSERT INTO kesplus_base.kesplus_module_role_permission ("id","role_id","permission_id","create_by","create_time","update_by","update_time","dept_id","module_id") VALUES
     ('189f54bb83604d7f8579ee627135ce88','4fc4d87dcab3488cb3d7487a58928af2','2026b40a02c5434a93ee6423591c7624','546508b9842c4e3698a1f2d3ae6fa917',sysdate,'546508b9842c4e3698a1f2d3ae6fa917',sysdate,'0','dfb8894291c34ac28e3458bba277e0ff'),
     ('a0ff5590600a40a4b08e14f5dcfa3483','4fc4d87dcab3488cb3d7487a58928af2','89257b095b1144a783bba49f699855c0','546508b9842c4e3698a1f2d3ae6fa917',sysdate,'546508b9842c4e3698a1f2d3ae6fa917',sysdate,'0','dfb8894291c34ac28e3458bba277e0ff'),
     ('0b60ef83ce34477b8c43f35360c6218f','4fc4d87dcab3488cb3d7487a58928af2','e6bd240f43344f028525b6abb1f065d6','546508b9842c4e3698a1f2d3ae6fa917',sysdate,'546508b9842c4e3698a1f2d3ae6fa917',sysdate,'0','dfb8894291c34ac28e3458bba277e0ff');