INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('e3330ff8677e4f22bb69fb262a4340d3', '200', 0, '1', 'kesplus', '{ "zh-CN" : "操作成功", "en-US" : "success" }', NULL);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('a58cbc27c3a2445b98e26a975137ba5d', '0100C', 1, '0', 'kesplus', '{ "zh-CN" : "返回了动态结果集", "en-US" : "KES error:dynamic_result_sets_returned" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('286f6a3fd11a47f7be18f7bccca9c999', '1004', 1, '0', 'kesplus', '{ "zh-CN" : "字符串数据右截断", "en-US" : "KES error:string_data_right_truncation" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('1b7c028d9b994ad2aeb458b0253e4704', '22001', 1, '0', 'kesplus', '{ "zh-CN" : "数据异常：字符串数据右截断", "en-US" : "KES error:string_data_right_truncation" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('651469d5821d48e382a399926c0660aa', '22003', 1, '0', 'kesplus', '{ "zh-CN" : "数据异常：数值超出范围", "en-US" : "KES error:numeric_value_out_of_range" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('c745a6dd102b4c64b62497f958a4422e', '22004', 1, '0', 'kesplus', '{ "zh-CN" : "数据异常：不允许空值", "en-US" : "KES error:null_value_not_allowed" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('4fcbba71f6f249bdac774a2b8dff2efc', '22005', 1, '0', 'kesplus', '{ "zh-CN" : "数据异常：赋值错误", "en-US" : "KES error:error_in_assignment" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('7d64c13ef04b4a7b9364b3d8da73f234', '22007', 1, '0', 'kesplus', '{ "zh-CN" : "数据异常：无效的日期时间格式", "en-US" : "KES error:invalid_datetime_format" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('7572e622c332475590570930a9d81f02', '22008', 1, '0', 'kesplus', '{ "zh-CN" : "数据异常：日期时间字段溢出", "en-US" : "KES error:datetime_field_overflow" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('cc9ea35a1fc94330bc7b02f2b91173b2', '22009', 1, '0', 'kesplus', '{ "zh-CN" : "数据异常：无效的时区偏移值", "en-US" : "KES error:invalid_time_zone_displacement_value" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('b82957b1026e43a699942a4608459c32', '2200B', 1, '0', 'kesplus', '{ "zh-CN" : "数据异常：转义字符冲突", "en-US" : "KES error:escape_character_conflict" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('38b5278520e94f35aee1003b6cc20101', '2200C', 1, '0', 'kesplus', '{ "zh-CN" : "数据异常：转义字符的使用无效", "en-US" : "KES error:invalid_use_of_escape_character" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('efe3ab0424a443949fb0728fdcb091e5', '2200D', 1, '0', 'kesplus', '{ "zh-CN" : "数据异常：无效的转义字节", "en-US" : "KES error:invalid_escape_octet" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('3d727c50930b4b6eba211e467c69ff34', '2200F', 1, '0', 'kesplus', '{ "zh-CN" : "数据异常：：零长度字符串", "en-US" : "KES error:zero_length_character_string" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('ccf929d8d1ae4c60ae4c76b2d110b36d', '2200G', 1, '0', 'kesplus', '{ "zh-CN" : "数据异常：最具体类型不匹配", "en-US" : "KES error:most_specific_type_mismatch" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('aca0ca35781a464ab1880db45a91322f', '2200H', 1, '0', 'kesplus', '{ "zh-CN" : "数据异常：序列生成器限制超出", "en-US" : "KES error:sequence_generator_limit_exceeded" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('327bbcac97194ea9bc5e58e42f40ace1', '2200L', 1, '0', 'kesplus', '{ "zh-CN" : "数据异常：不是XML文档", "en-US" : "KES error:not_an_xml_document" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('c18387ff440f4f30bb539f7100476e88', '2200M', 1, '0', 'kesplus', '{ "zh-CN" : "数据异常：无效的XML文档", "en-US" : "KES error:invalid_xml_document" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('8bcd2b81319a4fdcb9dc21eeb576790b', '2200N', 1, '0', 'kesplus', '{ "zh-CN" : "数据异常：无效的XML内容", "en-US" : "KES error:invalid_xml_content" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('769a316f5d14435d9b817eee6e23a080', '2200S', 1, '0', 'kesplus', '{ "zh-CN" : "数据异常：无效的XML注释", "en-US" : "KES error:invalid_xml_comment" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('94b004a0ad8b4facb9aabc945cf972ee', '2200T', 1, '0', 'kesplus', '{ "zh-CN" : "数据异常：无效的XML处理指令", "en-US" : "KES error:invalid_xml_processing_instruction" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('55d7f3d1bae14d319e79909e0c01e54b', '22010', 1, '0', 'kesplus', '{ "zh-CN" : "数据异常：无效的指示器参数值", "en-US" : "KES error:invalid_indicator_parameter_value" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('03a0573987f04b239eeed004c52abe17', '22012', 1, '0', 'kesplus', '{ "zh-CN" : "数据异常：除零错误", "en-US" : "KES error:division_by_zero" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('290b77d72f4e4918b95828e120f829af', '22018', 1, '0', 'kesplus', '{ "zh-CN" : "数据异常：无效的字符值用于转换", "en-US" : "KES error:invalid_character_value_for_cast" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('7ba100f28d3a4e8aa0699bb2f058c819', '22019', 1, '0', 'kesplus', '{ "zh-CN" : "数据异常：无效的转义字符", "en-US" : "KES error:invalid_escape_character" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('85a22430d2664a95953fab6c418c7011', '2201B', 1, '0', 'kesplus', '{ "zh-CN" : "数据异常：无效的正则表达式", "en-US" : "KES error:invalid_regular_expression" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('3abd6b03cfca4a9d9a261c40a7d4e9c5', '2201G', 1, '0', 'kesplus', '{ "zh-CN" : "数据异常：width_bucket函数的参数无效", "en-US" : "KES error:invalid_argument_for_width_bucket_function" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('2b0b3f546ea4479d927f036efec98935', '2201W', 1, '0', 'kesplus', '{ "zh-CN" : "数据异常：LIMIT子句中的无效行数", "en-US" : "KES error:invalid_row_count_in_limit_clause" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('03fe925afbc94103882fcaf87f6948e2', '2201X', 1, '0', 'kesplus', '{ "zh-CN" : "数据异常：RESULT OFFSET子句中的无效行数", "en-US" : "KES error:invalid_row_count_in_result_offset_clause" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('b46858c8424e4ab7a170680abc8825b6', '22021', 1, '0', 'kesplus', '{ "zh-CN" : "数据异常：字符不在字库中", "en-US" : "KES error:character_not_in_repertoire" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('4c458c29ee984d158e0da25140b88ab9', '22023', 1, '0', 'kesplus', '{ "zh-CN" : "数据异常：无效的参数值", "en-US" : "KES error:invalid_parameter_value" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('ec5fd810c1924606a05cdc9cb1cfbd43', '22026', 1, '0', 'kesplus', '{ "zh-CN" : "数据异常：字符串数据长度不匹配", "en-US" : "KES error:string_data_length_mismatch" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('4c701d59ea864faf8a19056b7e7fd14e', '2202E', 1, '0', 'kesplus', '{ "zh-CN" : "数据异常：数组下标错误", "en-US" : "KES error:array_subscript_error" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('dff48e64299941988eed9f8907a9002a', '22030', 1, '0', 'kesplus', '{ "zh-CN" : "数据异常：重复的JSON对象键值", "en-US" : "KES error:duplicate_json_object_key_value" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('10a1c42a7c4e4fb1b29e0d08151236d5', '22031', 1, '0', 'kesplus', '{ "zh-CN" : "数据异常：SQL JSON日期时间函数的参数无效", "en-US" : "KES error:invalid_argument_for_sql_json_datetime_function" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('31650b0963ec45a9bf38cbccb97a1184', '22032', 1, '0', 'kesplus', '{ "zh-CN" : "数据异常：无效的JSON文本", "en-US" : "KES error:invalid_json_text" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('bb38938aef964feabe48a75c967f7cd0', '0L000', 1, '0', 'kesplus', '{ "zh-CN" : "权限错误：无效的授予者", "en-US" : "KES error:invalid_grantor" }', -20998);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('8485fdb325f140f49918c3e2feba1be0', '22033', 1, '0', 'kesplus', '{ "zh-CN" : "数据异常：无效的SQL JSON下标", "en-US" : "KES error:invalid_sql_json_subscript" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('2fdadc149ab5461e8c096f1c2aa18583', '22034', 1, '0', 'kesplus', '{ "zh-CN" : "数据异常：多于一个的SQL JSON项目", "en-US" : "KES error:more_than_one_sql_json_item" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('9da28c40010d4fdba461ebe81af52b84', '22035', 1, '0', 'kesplus', '{ "zh-CN" : "数据异常：没有SQL JSON项目", "en-US" : "KES error:no_sql_json_item" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('a2592ed1160a4b08b096655bf00e54f4', '22036', 1, '0', 'kesplus', '{ "zh-CN" : "数据异常：非数值的SQL JSON项目", "en-US" : "KES error:non_numeric_sql_json_item" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('f337c778d46249b3a1b0ade05d91ac0c', '22037', 1, '0', 'kesplus', '{ "zh-CN" : "数据异常：JSON对象中的非唯一键", "en-US" : "KES error:non_unique_keys_in_a_json_object" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('27d9ed30f16c49a99309c4482813eac9', '22038', 1, '0', 'kesplus', '{ "zh-CN" : "错误：需要单例SQL JSON项目", "en-US" : "KES error:singleton_sql_json_item_required" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('487cb31951004678808d60efa0dd645d', '22039', 1, '0', 'kesplus', '{ "zh-CN" : "数据异常：未找到SQL JSON数组", "en-US" : "KES error:sql_json_array_not_found" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('8a1597f445cd467e86c93f7a59a08492', '2203A', 1, '0', 'kesplus', '{ "zh-CN" : "数据异常：未找到SQL JSON成员", "en-US" : "KES error:sql_json_member_not_found" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('d89c748787de4ee9bad21506d15457ec', '2203B', 1, '0', 'kesplus', '{ "zh-CN" : "数据异常：未找到SQL JSON数字", "en-US" : "KES error:sql_json_number_not_found" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('746b29438eb14b2a820c7daf9c298c91', '22P01', 1, '0', 'kesplus', '{ "zh-CN" : "数据异常：浮点异常", "en-US" : "KES error:floating_point_exception" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('8193d6d351484622b95ec341b4fac73c', '22P03', 1, '0', 'kesplus', '{ "zh-CN" : "数据异常：无效的二进制表示", "en-US" : "KES error:invalid_binary_representation" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('792353155d054190a5d997e8a3c5469c', '23502', 1, '0', 'kesplus', '{ "zh-CN" : "错误：输入参数不完整", "en-US" : "KES error:please confirm table required fields" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('32072d96aa5b41d7ab119797b7eb8429', '26000', 1, '0', 'kesplus', '{ "zh-CN" : "错误：无效的SQL语句名称", "en-US" : "KES error:invalid_sql_statement_name" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('dffab4a3791d4dbaa72703240e508e4c', '28000', 1, '0', 'kesplus', '{ "zh-CN" : "错误：无效的授权规范", "en-US" : "KES error:invalid_authorization_specification" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('89655f93fa404002970a0153ad754aa6', '28P01', 1, '0', 'kesplus', '{ "zh-CN" : "错误：无效的密码", "en-US" : "KES error:invalid_password" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('8220ca23ed83485287fb53531493326b', '2B000', 1, '0', 'kesplus', '{ "zh-CN" : "错误：仍存在相关特权描述符", "en-US" : "KES error:dependent_privilege_descriptors_still_exist" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('40d2fcd2ca1c4d66a80109097d0d56ee', '2BP01', 1, '0', 'kesplus', '{ "zh-CN" : "错误：仍存在相关对象", "en-US" : "KES error:dependent_objects_still_exist" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('9a013e06b7b747839a56f3a503a7e7df', '2D000', 1, '0', 'kesplus', '{ "zh-CN" : "错误：无效的事务终止", "en-US" : "KES error:invalid_transaction_termination" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('08623ecc48594d5c9a961cfb74a80b1b', '2F002', 1, '0', 'kesplus', '{ "zh-CN" : "错误：不允许修改SQL数据", "en-US" : "KES error:modifying_sql_data_not_permitted" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('6221d33db69c40e7b7ce10bb4f936f72', '2F003', 1, '0', 'kesplus', '{ "zh-CN" : "错误：尝试禁止的SQL语句", "en-US" : "KES error:prohibited_sql_statement_attempted" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('f89bc7a90086420985c92dc16c909c60', '2F004', 1, '0', 'kesplus', '{ "zh-CN" : "错误：不允许读取SQL数据", "en-US" : "KES error:reading_sql_data_not_permitted" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('02f6225e8cb34af3a48e0f6cf0abda51', '2F005', 1, '0', 'kesplus', '{ "zh-CN" : "错误：函数执行没有返回语句", "en-US" : "KES error:function_executed_no_return_statement" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('97631546cc984a6495fcaa6e1731dfab', '34000', 1, '0', 'kesplus', '{ "zh-CN" : "错误：无效的游标名称", "en-US" : "KES error:invalid_cursor_name" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('a8807257fbb74422aee8a9fc662d2f2b', '38002', 1, '0', 'kesplus', '{ "zh-CN" : "错误：不允许修改SQL数据", "en-US" : "KES error:modifying_sql_data_not_permitted" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('34c36a9990c6488188a4c77756b59b22', '38003', 1, '0', 'kesplus', '{ "zh-CN" : "错误：尝试禁止的SQL语句", "en-US" : "KES error:prohibited_sql_statement_attempted" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('1b227dee5fe14ef785023ef342ce613b', '39001', 1, '0', 'kesplus', '{ "zh-CN" : "错误：返回了无效的SQL状态", "en-US" : "KES error:invalid_sqlstate_returned" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('32a84b4414e94c98ac1191de294e1165', '39004', 1, '0', 'kesplus', '{ "zh-CN" : "错误：不允许空值", "en-US" : "KES error:null_value_not_allowed" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('d159ffe0c4af4afda119796868ff15dc', '3D000', 1, '0', 'kesplus', '{ "zh-CN" : "数据库错误：无效的目录名称", "en-US" : "KES error:invalid_catalog_name" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('e3aa90c779474567adf6d844c93861d0', '3F000', 1, '0', 'kesplus', '{ "zh-CN" : "数据库错误：无效的模式名称", "en-US" : "KES error:invalid_schema_name" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('b71d0540f77e4e4f83fcd7e391160b58', '40000', 1, '0', 'kesplus', '{ "zh-CN" : "错误：事务回滚", "en-US" : "KES error:transaction_rollback" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('d6e93c623c3a4f7f87e237ac12f8e34c', '40001', 1, '0', 'kesplus', '{ "zh-CN" : "错误：序列化失败", "en-US" : "KES error:serialization_failure" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('db102eb1e1cd4b31be76fcc5f73a85f8', '40002', 1, '0', 'kesplus', '{ "zh-CN" : "错误：事务完整性约束违规", "en-US" : "KES error:transaction_integrity_constraint_violation" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('03319c3602e246ce97735eb8566e0f19', '40P01', 1, '0', 'kesplus', '{ "zh-CN" : "错误：检测到死锁", "en-US" : "KES error:deadlock_detected" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('5bb98c82f8a746c084991313c9a1ff7b', '42000', 1, '0', 'kesplus', '{ "zh-CN" : "语法错误或访问规则违规", "en-US" : "KES error:syntax_error_or_access_rule_violation" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('8b349282d8694a40835189bd757e1755', '42601', 1, '0', 'kesplus', '{ "zh-CN" : "语法错误", "en-US" : "KES error:syntax_error" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('4d86180ce9ce44f29f359e49ccffcc54', '42602', 1, '0', 'kesplus', '{ "zh-CN" : "语法错误：无效的名称", "en-US" : "KES error:invalid_name" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('ec2f0ac6755b40778f44f662ccd5fcae', '42611', 1, '0', 'kesplus', '{ "zh-CN" : "语法错误：无效的列定义", "en-US" : "KES error:invalid_column_definition" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('27c29e27a029455aaa5d3153a8deb203', '42622', 1, '0', 'kesplus', '{ "zh-CN" : "语法错误：名称过长", "en-US" : "KES error:name_too_long" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('a51ea23dcba647f187c4eb77a447fb56', '42701', 1, '0', 'kesplus', '{ "zh-CN" : "语法错误：重复的列", "en-US" : "KES error:duplicate_column" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('ef280b1c8d124e479e0cb75374a9d432', '42703', 1, '0', 'kesplus', '{ "zh-CN" : "语法错误：未定义的列", "en-US" : "KES error:undefined_column" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('6fef4005b24546e7889ffc5b59bc6302', '42704', 1, '0', 'kesplus', '{ "zh-CN" : "语法错误：未定义的对象", "en-US" : "KES error:undefined_object" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('503d6f40f7344810bdf7c0272114a49b', '42710', 1, '0', 'kesplus', '{ "zh-CN" : "错误：重复的对象", "en-US" : "KES error:duplicate_object" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('af289c6dc76e4bb9875338e9bcf17a90', '42712', 1, '0', 'kesplus', '{ "zh-CN" : "错误：重复的别名", "en-US" : "KES error:duplicate_alias" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('10b7f0dde3b2426783cc5658f6d171bf', '42723', 1, '0', 'kesplus', '{ "zh-CN" : "错误：重复的函数", "en-US" : "KES error:duplicate_function" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('b4c1d552cba747a891d472bc90843c79', '42804', 1, '0', 'kesplus', '{ "zh-CN" : "语法错误：数据类型不匹配", "en-US" : "KES error:datatype_mismatch" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('d059d5cf37e74275ba5e32a3a2fc48fe', '42809', 1, '0', 'kesplus', '{ "zh-CN" : "语法错误：错误的对象类型", "en-US" : "KES error:wrong_object_type" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('0aeff281c3e64867b0067637ea99042c', '42830', 1, '0', 'kesplus', '{ "zh-CN" : "错误：无效的外键", "en-US" : "KES error:invalid_foreign_key" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('a23a93c110c04e838c6a1023f09faea0', '42846', 1, '0', 'kesplus', '{ "zh-CN" : "错误：无法强制转换", "en-US" : "KES error:cannot_coerce" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('5e84a6701fed43d0921b0aa2e9dd4b34', '42883', 1, '0', 'kesplus', '{ "zh-CN" : "错误：未定义的函数", "en-US" : "KES error:undefined_function" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('5e73492821bb4745a7b4614bff5556f3', '42P01', 1, '0', 'kesplus', '{ "zh-CN" : "错误：未定义的表", "en-US" : "KES error:undefined_table" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('eb06cb70c45343808dd4741c47e72514', '42P02', 1, '0', 'kesplus', '{ "zh-CN" : "语法错误：未定义的参数", "en-US" : "KES error:undefined_parameter" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('85b2b5ba59e049a28c41dddd1dd44c16', '42P03', 1, '0', 'kesplus', '{ "zh-CN" : "错误：重复的游标", "en-US" : "KES error:duplicate_cursor" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('d3dbce60258c4f78a0d2317c9accf69c', '42P10', 1, '0', 'kesplus', '{ "zh-CN" : "错误：无效的列引用", "en-US" : "KES error:invalid_column_reference" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('95dd24a54b1948699de953086b5efe3e', '42P11', 1, '0', 'kesplus', '{ "zh-CN" : "错误：无效的游标定义", "en-US" : "KES error:invalid_cursor_definition" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('0661b57217eb44be99a687fefe842a1d', '42P12', 1, '0', 'kesplus', '{ "zh-CN" : "错误：无效的数据库定义", "en-US" : "KES error:invalid_database_definition" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('bc084b47457149e2b7fc6a33eaae47c3', '42P13', 1, '0', 'kesplus', '{ "zh-CN" : "错误：无效的函数定义", "en-US" : "KES error:invalid_function_definition" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('8aba1dc1aedf4341b57b4613fdfd4f9e', '44000', 1, '0', 'kesplus', '{ "zh-CN" : "错误：违反了WITH CHECK OPTION", "en-US" : "KES error:with_check_option_violation" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('70836bb90696416987fafce6fa9ee0eb', '53000', 1, '0', 'kesplus', '{ "zh-CN" : "数据库错误：资源不足", "en-US" : "KES error:insufficient_resources" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('57c3c182909b4a13ab0eca574e17e3b7', '53100', 1, '0', 'kesplus', '{ "zh-CN" : "资源不足：磁盘已满", "en-US" : "KES error:disk_full" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('59b82000341940afb79808b617d5ab20', '53200', 1, '0', 'kesplus', '{ "zh-CN" : "资源不足：内存不足", "en-US" : "KES error:out_of_memory" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('0aa66d135a074ffebcb3ddfbbee6fdbd', '53300', 1, '0', 'kesplus', '{ "zh-CN" : "资源不足：数据库连接过多", "en-US" : "KES error:too_many_connections" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('5208b04ee9fe49a18c1ffe9fd0c822d3', '53400', 1, '0', 'kesplus', '{ "zh-CN" : "数据库错误：配置限制超过", "en-US" : "KES error:configuration_limit_exceeded" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('e815f955580844488f8fc176fe5e335e', '54000', 1, '0', 'kesplus', '{ "zh-CN" : "数据库错误：程序限制超过", "en-US" : "KES error:program_limit_exceeded" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('bdf1670b5ab84bf19a53b00633399454', '54001', 1, '0', 'kesplus', '{ "zh-CN" : "数据库错误：语句过于复杂", "en-US" : "KES error:statement_too_complex" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('1fe793dd0994403fbcd5ac0ee99c65bc', '54011', 1, '0', 'kesplus', '{ "zh-CN" : "数据库错误：列过多", "en-US" : "KES error:too_many_columns" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('53f14fddd7aa4c1d99b66e50562704de', '54023', 1, '0', 'kesplus', '{ "zh-CN" : "数据库错误：参数过多", "en-US" : "KES error:too_many_arguments" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('b8b3119f0ddc4c4d9af848e406d5a88c', '55006', 1, '0', 'kesplus', '{ "zh-CN" : "错误：对象正在使用中", "en-US" : "KES error:object_in_use" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('dbe5fb77a3ec4f11b4815d15d2b2561f', '57P03', 1, '0', 'kesplus', '{ "zh-CN" : "数据库错误：当前无法连接", "en-US" : "KES error:cannot_connect_now" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('8d2e6cd8656f44d39026ff8a3629fbd5', '57P04', 1, '0', 'kesplus', '{ "zh-CN" : "数据库错误：数据库已删除", "en-US" : "KES error:database_dropped" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('9396b3a68f2249d69a71ea528c6c7f06', '57P05', 1, '0', 'kesplus', '{ "zh-CN" : "数据库错误：空闲会话超时", "en-US" : "KES error:idle_session_timeout" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('1c7924da6cff4118aaaf2b1b4cf141f3', '58000', 1, '0', 'kesplus', '{ "zh-CN" : "数据库错误：系统错误", "en-US" : "KES error:system_error" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('a2f3b03eebd34c489484df04ff56bbd5', '58030', 1, '0', 'kesplus', '{ "zh-CN" : "数据库错误：IO错误", "en-US" : "KES error:io_error" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('9e3cb7897867405bbfada29b0173fa9c', '72000', 1, '0', 'kesplus', '{ "zh-CN" : "数据库错误：快照过时", "en-US" : "KES error:snapshot_too_old" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('484d1a1eb3974f26b5171f65075cee79', '72001', 1, '0', 'kesplus', '{ "zh-CN" : "数据库错误：系统繁忙，请刷新", "en-US" : "KES error:to busy, please refresh" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('46233da789784ecbb6e61133fdfc290d', '8000', 1, '0', 'kesplus', '{ "zh-CN" : "数据库错误：连接异常", "en-US" : "KES error:connection_exception" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('25ded21bb9384a13b8d5fb4e7d15c288', '8001', 1, '0', 'kesplus', '{ "zh-CN" : "数据库错误：SQL客户端无法建立SQL连接", "en-US" : "KES error:sqlclient_unable_to_establish_sqlconnection" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('bb960c103e7c49b1810460dfc7202edf', '8004', 1, '0', 'kesplus', '{ "zh-CN" : "数据库错误：SQL服务器拒绝建立SQL连接", "en-US" : "KES error:sqlserver_rejected_establishment_of_sqlconnection" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('769fac4e1b214fb587ec2f9064186c45', '8006', 1, '0', 'kesplus', '{ "zh-CN" : "数据库错误：连接失败", "en-US" : "KES error:connection_failure" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('c87ada5540934e6780b39a1e8a76ea60', 'P0003', 1, '0', 'kesplus', '{ "zh-CN" : "返回的行数过多", "en-US" : "KES error:too_many_rows" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('505f883284094370af631e951f65a9de', 'P0004', 1, '0', 'kesplus', '{ "zh-CN" : "断言失败", "en-US" : "KES error:assert_failure" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('c1a2e5346ccc4745a188f725492d3510', 'XX000', 1, '0', 'kesplus', '{ "zh-CN" : "系统异常，请刷新", "en-US" : "KES error:internal_error" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('479607b991a94b3796b0db4c3805ff11', 'XX001', 1, '0', 'kesplus', '{ "zh-CN" : "数据库错误：数据损坏", "en-US" : "KES error:data_corrupted" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('1f83944acd3a4c24ad39bf4a80ddcc76', 'XX002', 1, '0', 'kesplus', '{ "zh-CN" : "数据库错误：索引损坏", "en-US" : "KES error:index_corrupted" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('1f83944acd3a4c24ad39bf4a8addcc76', '23505', 1, '0', 'kesplus', '{ "zh-CN" : "保存数据失败，违反唯一约束", "en-US" : "KES error:failed to save data to database" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('db527d346eac4e638fc79adcee839fc4', 'kesplus_generator_1002', 0, '0', 'kesplus', '{ "zh-CN" : "请输入数据！", "en-US" : "Please input data！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('16ab7dae362f42289f2b71910c9acd25', '0LP01', 1, '0', 'kesplus', '{ "zh-CN" : "权限错误：无效的授予操作", "en-US" : "KES error:invalid_grant_operation" }', -20998);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('5828bf1df3b94728b78d2462327862f1', '0P000', 1, '0', 'kesplus', '{ "zh-CN" : "权限错误：无效的角色规范", "en-US" : "KES error:invalid_role_specification" }', -20998);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('e825329aef9844a7906857151e2fee3a', '1006', 1, '0', 'kesplus', '{ "zh-CN" : "权限错误：未撤销权限", "en-US" : "KES error:privilege_not_revoked" }', -20998);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('e46655cd79ff46ee9a3061b001698d0f', '1007', 1, '0', 'kesplus', '{ "zh-CN" : "权限错误：未授予权限", "en-US" : "KES error:privilege_not_granted" }', -20998);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('deb2ffb229dd4199ad8aef687b0dfdd1', 'kesplus_login_1004', 0, '0', 'kesplus', '{ "zh-CN" : "用户无权限登录", "en-US" : "the user has no auth to login" }', -20998);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('cac89940906a4daab7d6170cbb7c728b', 'kesplus_menu_1004', 0, '0', 'kesplus', '{ "zh-CN" : "请先删除下级关联权限点!", "en-US" : "Delete the subordinate associated permission first!" }', -20998);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('29b9c5979f314216b49c49b526c7b6ea', 'kesplus_platform_pkg_1012', 0, '0', 'kesplus', '{ "zh-CN" : "业务表不存在或者无数据权限", "en-US" : "table not exists or no permission" }', -20998);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('3890880dd3b1423b9aaaf78308984802', 'kesplus_platform_pkg_1016', 0, '0', 'kesplus', '{ "zh-CN" : "对象[%]无操作权限", "en-US" : "no permission for Object [%]" }', -20998);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('b296e5af1e36421da8bd1469264f2572', 'kesplus_policy_1004', 0, '0', 'kesplus', '{ "zh-CN" : "不能直接删除已关联角色的数据权限!", "en-US" : "Cannot directly delete the data rights of an associated role!" }', -20998);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('a5f0dc1d15884103894dea098f8ca3cb', 'kesplus_policy_1007', 0, '0', 'kesplus', '{ "zh-CN" : "数据权限状态错误!", "en-US" : "The data permission status is incorrect!" }', -20998);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('24b690e07f3d4e57ab9d5b5f1ec530d1', 'kesplus_sysuser_1001', 0, '0', 'kesplus', '{ "zh-CN" : "权限不足", "en-US" : "auth not enough" }', -20998);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('82684c0f4f9c4ac379009af67c171b50', 'user_not_enough_auth', 0, '0', 'kesplus', '{ "zh-CN" : "当前用户无权限更改数据", "en-US" : "you are not authorized to change the data" }', -20998);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('6debc149fa4b4a4eb4fde1b12b586e4d', '2000', 1, '0', 'kesplus', '{ "zh-CN" : "没有数据", "en-US" : "KES error:no_data" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('7cd9dab28d6f4aff97f967c2ff9aba94', '22022', 1, '0', 'kesplus', '{ "zh-CN" : "数据异常：指示器溢出", "en-US" : "KES error:indicator_overflow" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('d12d460091674c888bde489b685f76f4', '42501', 1, '0', 'kesplus', '{ "zh-CN" : "权限不足", "en-US" : "KES error:insufficient_privilege" }', -20998);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('7cd7a63b08d447318307e89936b7f72f', '403', 0, '0', 'kesplus', '{ "zh-CN" : "拒绝访问", "en-US" : "Access denied" }', NULL);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('2d6763abafb54ce2a110e2956e273348', '404', 0, '0', 'kesplus', '{ "zh-CN" : "资源不存在", "en-US" : "Resource does not exist" }', NULL);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('9f18d4fa214d4eb88ed86ac3a948d173', '500', 0, '0', 'kesplus', '{ "zh-CN": "业务[%s]执行失败","en-US": "System error for this restful [%s], please notice the administrator"}', NULL);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('0f6508bc02ea463fa04356128325559a', 'kesplus_300', 0, '0', 'kesplus', '{ "zh-CN" : "参数验证失败", "en-US" : "Parameter verification failed" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('ba5e2100fcb54593a0cae7d2bc0cdde9', 'kesplus_app_1000', 0, '0', 'kesplus', '{ "zh-CN" : "数据库已存在，请修改应用编码", "en-US" : "Database already exists" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('eaa267a94bad4a96a991bf2e13b57ff0', 'kesplus_app_1001', 0, '0', 'kesplus', '{ "zh-CN" : "应用创建失败", "en-US" : "App create failed" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('de470aeb18ae4131bbc167589ac57002', 'kesplus_app_1002', 0, '0', 'kesplus', '{ "zh-CN" : "初始化前端应用配置信息失败", "en-US" : "Front application config initialization failed" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('f8627c877b1c46bcacdf32f684cc3654', 'kesplus_app_1003', 0, '0', 'kesplus', '{ "zh-CN" : "拷贝系统模块失败", "en-US" : "Failed to copy system module" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('7a6f4f962df74bc0a8b8db8753884335', 'kesplus_app_1004', 0, '0', 'kesplus', '{ "zh-CN" : "环境配置问题", "en-US" : "Environment configuration error" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('4ae6d0043cd44b108cd867b5439249e3', 'kesplus_app_2000', 0, '0', 'kesplus', '{ "zh-CN" : "文件校验未通过，请重新上传。", "en-US" : "File verification failed,please upload again" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('aa7af24f5f31486da60a02d6983244ad', 'kesplus_app_2001', 0, '0', 'kesplus', '{ "zh-CN" : "应用导出失败", "en-US" : "App export failed" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('acd82642ab814665acdddf1a8614be79', 'kesplus_app_2002', 0, '0', 'kesplus', '{ "zh-CN" : "应用导入失败", "en-US" : "App import failed" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('0fb1204d25d34212a28b6cb90b7ea95a', 'kesplus_app_3000', 0, '0', 'kesplus', '{ "zh-CN" : "appCode不能为空", "en-US" : "AppCode cannot be empty " }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('b9c8f17109ac4f099b56c04db699728e', 'kesplus_app_3001', 0, '0', 'kesplus', '{ "zh-CN" : "系统默认编码,请输入其他编码", "en-US" : "the default code cannot be used, please enter another one" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('22c727336cd746c2a956d515fd2e5a29', 'kesplus_app_3002', 0, '0', 'kesplus', '{ "zh-CN" : "应用名称已存在", "en-US" : "application name already exists" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('2c3ffb19b7654565bcc37fb3e75bdc09', 'kesplus_app_3003', 0, '0', 'kesplus', '{ "zh-CN" : "应用管理员名称已存在", "en-US" : "the application administrator name already exist" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('6042fd01be2049d4a028ec913cf5ae4b', 'kesplus_app_3004', 0, '0', 'kesplus', '{ "zh-CN" : "APPID不能为空", "en-US" : "the APPID cannot be null" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('e39f3188375c43c6b2f3ed5e496f086e', 'kesplus_app_3005', 0, '0', 'kesplus', '{ "zh-CN" : "APPID不存在", "en-US" : "the APPID not present" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('3ae89e4c33c94c5094a030b8b5b1d1fa', 'kesplus_app_3006', 0, '0', 'kesplus', '{ "zh-CN" : "应用编码已存在", "en-US" : "the app code has already exists" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('df6082ff73c14e028a276ef5a3f1da11', 'kesplus_app_3007', 0, '0', 'kesplus', '{ "zh-CN" : "当前分类已绑定应用，不能删除。", "en-US" : "the current category has been bound to an application and cannot be deleted" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('90bcb5288efa4dddafd0b10ee9f1529b', 'kesplus_app_3008', 0, '0', 'kesplus', '{ "zh-CN" : "APPCODE不能为空。", "en-US" : "the APPCODE cannot be null" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('ae7cb541705f4720b55fb8c4eefe5f63', 'kesplus_appbuild_1001', 0, '0', 'kesplus', '{ "zh-CN" : "根据ID查询对象时，Id条件不能为空！", "en-US" : "Query Object By Id,The Id condition cannot be empty！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('f41f417c125140bdb9cda7ea06987c65', 'kesplus_build_501', 0, '0', 'kesplus', '{ "zh-CN" : "不支持构建类型", "en-US" : "Unsupported build type" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('b0c39917e2344bd9813ddd5205e3a6cd', 'kesplus_build_502', 0, '0', 'kesplus', '{ "zh-CN" : "构建更新包和补丁包时，必须选择起始Tag", "en-US" : "When building update and patch packages,the starting tag must be selected" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('654d0194d0144f84ba4cb9fcc5d43906', 'kesplus_db_000', 0, '0', 'kesplus', '{ "zh-CN" : "数据库错误", "en-US" : "KES error" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('a9c8931ff6944776883c563113129515', 'kesplus_document_1000', 0, '0', 'kesplus', '{ "zh-CN" : "文件夹已存在", "en-US" : "Folder already exists" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('8622ca8d97184f428bb1d0f6d6462f40', 'kesplus_document_1001', 0, '0', 'kesplus', '{ "zh-CN" : "文件已存在", "en-US" : "File already exists" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('5808681a7a404711894363b4a593e4b0', 'kesplus_document_1002', 0, '0', 'kesplus', '{ "zh-CN" : "文件路径获取失败", "en-US" : "Failed to get file path" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('904a1742074b416e8520b8c0366fa237', 'kesplus_document_1003', 0, '0', 'kesplus', '{ "zh-CN" : "存在子目录,无法删除", "en-US" : "There are subdirector that cannot be deleted" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('33eb4cd6116c42cb94c27a4c361088c6', 'kesplus_document_1004', 0, '0', 'kesplus', '{ "zh-CN" : "文件不存在", "en-US" : "File not exists" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('18fc6bb212e84005bc6db3ccaeb7ea84', 'kesplus_document_1021', 0, '0', 'kesplus', '{ "zh-CN" : "数据类型只能为doc或doc-dir！", "en-US" : "The data type can only be doc or doc-dir！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('de6e359be852435fb9d1acb907b44e19', 'kesplus_file_1001', 0, '0', 'kesplus', '{ "zh-CN" : "文件类型不能为空！", "en-US" : "The file type cannot be empty！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('dd8927fc5f634de4a3fc92bdab20b768', 'kesplus_file_1002', 0, '0', 'kesplus', '{ "zh-CN" : "文件后缀不能为空！", "en-US" : "The file suffix cannot be empty！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('a35b148e5f84437eb02292bd009b5f8d', 'kesplus_file_1003', 0, '0', 'kesplus', '{ "zh-CN" : "文件路径不能为空！", "en-US" : "The file path cannot be empty！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('ab203174d0a34085b43ee35f520f0777', 'kesplus_file_500', 0, '0', 'kesplus', '{ "zh-CN" : "文件为空", "en-US" : "Folder is empty" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('50e1fb1dcea64fa7aaaea445844cc73c', 'kesplus_filter_1001', 0, '0', 'kesplus', '{ "zh-CN" : "过滤器编码不能为空！", "en-US" : "The filter code cannot be empty！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('b5aead2cb5f7437b80521d94804b6513', 'kesplus_filter_1002', 0, '0', 'kesplus', '{ "zh-CN" : "过滤器名称不能为空！", "en-US" : "The filter name cannot be empty！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('9bdac633e7c9483d9aa89f9bf86c3c65', 'kesplus_filter_1003', 0, '0', 'kesplus', '{ "zh-CN" : "顺序范围为[1-999]！", "en-US" : "The order ranges [1-999]！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('1fcb8fe4b2cd4eafbcd3162c30f08250', 'kesplus_filter_1004', 0, '0', 'kesplus', '{ "zh-CN" : "过滤器ID不能为空！", "en-US" : "The filter ID cannot be empty！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('7a5c18c09f48416f87fe39b67974a58e', 'kesplus_filter_1005', 0, '0', 'kesplus', '{ "zh-CN" : "系统过滤器不允许编辑！", "en-US" : "System filter is not edit！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('eb710694649745d0bcf69f35508ad398', 'kesplus_filter_1006', 0, '0', 'kesplus', '{ "zh-CN" : "过滤器[%]不存在！", "en-US" : "Filter[%]is not exists！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('353ac36c353f47c0a1e368965d79969c', 'kesplus_filter_1007', 0, '0', 'kesplus', '{ "zh-CN" : "系统过滤器不允许删除！", "en-US" : "System filter is not drop！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('02438aec05d4422892510735951d1425', 'kesplus_filter_1008', 0, '0', 'kesplus', '{
  "zh-CN": "错误的版本编号[%]！",
  "en-US": "Error version code[%]！"
}', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('9164cadea84f4308beb8c47ac998989d', 'kesplus_form_1001', 0, '0', 'kesplus', '{ "zh-CN" : "模型名称不能为空！", "en-US" : "The form name cannot be empty！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('2cc4b3a513574b92a911b5145497e4ad', 'kesplus_form_1002', 0, '0', 'kesplus', '{ "zh-CN" : "模型编码不能为空！", "en-US" : "The form code cannot be empty！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('aaa35bdc21494e629678f14e544fb19f', 'kesplus_form_1003', 0, '0', 'kesplus', '{ "zh-CN" : "编码 [%] 已存在！", "en-US" : "The encode [%] already exists！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('92d552e8a8ce44ef86c2fd785e30359f', 'kesplus_form_1004', 0, '0', 'kesplus', '{ "zh-CN" : "模块ID不能为空！", "en-US" : "The module ID cannot be empty！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('996e6cca16c84f52bb240cfcb06ddeff', 'kesplus_form_1005', 0, '0', 'kesplus', '{ "zh-CN" : "表单ID不能为空！", "en-US" : "The form ID cannot be empty！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('b545dcee31494309a57cfc98ef7f8a9a', 'kesplus_form_1006', 0, '0', 'kesplus', '{ "zh-CN" : "该模型已绑定流程,不允许删除！", "en-US" : "The model is bound to a process and is  not allowed to be deleted！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('d6cda50ec6d44aeba2551870b084acf4', 'kesplus_form_1007', 0, '0', 'kesplus', '{ "zh-CN" : "表单模型不存在！", "en-US" : "The formmodel not exists！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('348a4c9c638340b199845697e81276b2', 'kesplus_form_1008', 0, '0', 'kesplus', '{ "zh-CN" : "请配置模型表信息！", "en-US" : "Configure the model table information！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('885dba3ad72d4e7fa1b565ad8dda8017', 'kesplus_form_1009', 0, '0', 'kesplus', '{ "zh-CN" : "请设置子表 [%] 外键字段！", "en-US" : "Set the foreign key [%]！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('370978446d694ed7a20183fbfe8492de', 'kesplus_form_1010', 0, '0', 'kesplus', '{ "zh-CN" : "请配置表单属性！", "en-US" : "Please configure the form properties!" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('fcbd2a1cba04406c9669c3d40b0b4084', 'kesplus_form_1011', 0, '0', 'kesplus', '{ "zh-CN" : "请配置列表属性！", "en-US" : "Please configure the list properties!" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('487c1f466fa14186ace01ecae500a95b', 'kesplus_form_1012', 0, '0', 'kesplus', '{ "zh-CN" : "请输入模块ID！", "en-US" : "Please input module ID!" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('205ad6fecec44725a5fe9a4e4470e9fc', 'kesplus_form_1013', 0, '0', 'kesplus', '{ "zh-CN" : "请输入表名！", "en-US" : "Please input table name！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('897537f38c9d4b0da91e8471ae0614d6', 'kesplus_formbind_1001', 0, '0', 'kesplus', '{ "zh-CN" : "请输入流程ID！", "en-US" : "Please input process ID！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('25f51ce51ea94926a0aa895ffd664ea4', 'kesplus_formbind_1002', 0, '0', 'kesplus', '{ "zh-CN" : "请输入表单编码！", "en-US" : "Please input form code ID！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('b2756a75a3eb498181bf9afc8f713a19', 'kesplus_formbind_1003', 0, '0', 'kesplus', '{ "zh-CN" : "ID不存在！", "en-US" : "ID is not exists！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('a187bb51ed6b4c209ddf3d6036d84926', 'kesplus_formbind_1004', 0, '0', 'kesplus', '{ "zh-CN" : "配置ID不能为空！", "en-US" : "Disposition ID is not empty！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('63565c9c753c4de1b3bedbfb13457b0b', 'kesplus_formbind_1005', 0, '0', 'kesplus', '{ "zh-CN" : "节点ID不能为空！", "en-US" : "Node ID is not empty！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('347c75e8aa774576becd411730e20493', 'kesplus_formbind_1006', 0, '0', 'kesplus', '{ "zh-CN" : "配置不存在！", "en-US" : "Disposition  is not empty！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('1cd8d46dfefe4caa824c12442985d4fe', 'kesplus_formdata_1001', 0, '0', 'kesplus', '{ "zh-CN" : "要保存的表单数据不能为空！", "en-US" : "The Form Data to save cannot be empty!" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('4fdb8549a84b480aa4ddebb16ba9fe20', 'kesplus_formdata_1002', 0, '0', 'kesplus', '{ "zh-CN" : "请选择删除数据！", "en-US" : "Please select the data you want to delete！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('ab9596ad8503481f8cb8474200ee11b7', 'kesplus_formdata_1003', 0, '0', 'kesplus', '{ "zh-CN" : "要修改的表单数据不能为空！", "en-US" : "The Form Data you want to modify cannot be empty！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('9d8c4eaca85d4fda9a95e9beac0b928e', 'kesplus_formdata_1004', 0, '0', 'kesplus', '{ "zh-CN" : "名称[%]已存在！", "en-US" : "name [%] already exists！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('bc4a0911f3c54702992856eec99e964f', 'kesplus_formdata_1005', 0, '0', 'kesplus', '{ "zh-CN" : "名称不能为空！", "en-US" : "name can not be empty！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('9ebb45872773490ba9a68c1c8ef8a9da', 'kesplus_formdata_1006', 0, '0', 'kesplus', '{ "zh-CN" : "[%]不能为空！", "en-US" : "[%] can not be empty！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('2a15c388a57e401ea350f3b9fc7805e6', 'kesplus_formgenerator_1001', 0, '0', 'kesplus', '{ "zh-CN" : "未知表单类型,生成代码失败！", "en-US" : "The form type is unknown and the code generation fails！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('0f07136de9964ff0b3c68788bedbe10a', 'kesplus_formgenerator_1002', 0, '0', 'kesplus', '{ "zh-CN" : "请输入配置信息！", "en-US" : "Please input Disposition info！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('4c3fef5f855e424ab95e19c353316539', 'kesplus_formgenerator_1003', 0, '0', 'kesplus', '{
  "zh-CN": "配置不存在！",
  "en-US": "this setting is not exist"
}', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('35b4180779d44b69b2a324165354bf2e', 'kesplus_func_1000', 0, '0', 'kesplus', '{ "zh-CN" : "名称已存在", "en-US" : "the name has already exists" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('021eae46e8b44389966159dcf6949613', 'kesplus_func_1001', 0, '0', 'kesplus', '{ "zh-CN" : "当前目录下存在数据，不能删除", "en-US" : "the dir was not be allowed to deleted cause data exists in it" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('9e723301b8b44e58bec574fffd5538ca', 'kesplus_func_1002', 0, '0', 'kesplus', '{ "zh-CN" : "ID不能为空", "en-US" : "ID cannot be null" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('9a2c374b6a334b7495b1f33a01d488b2', 'kesplus_func_1003', 0, '0', 'kesplus', '{ "zh-CN" : "该对象已存在rest接口", "en-US" : "the object has been a RESTful" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('cb3635dce249444cba656c4a68af720c', 'kesplus_func_1004', 0, '0', 'kesplus', '{ "zh-CN" : "code不能为空", "en-US" : "code cannot be null" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('89c225982d32486987d4462effe04cd8', 'kesplus_func_1005', 0, '0', 'kesplus', '{ "zh-CN" : "code应该为functions或procedures", "en-US" : "code must be functions or procedures" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('42bb96c303414bd4b856a61c4cd4a42b', 'kesplus_func_1006', 0, '0', 'kesplus', '{ "zh-CN" : "已发布为API不能删除", "en-US" : "not allowed to delete cause it has been publish to the RESTful API" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('aad7930565674535b319334a19926d83', 'kesplus_func_1007', 0, '0', 'kesplus', '{ "zh-CN" : "未关联函数或存储过程", "en-US" : "it is not related to a function or procedure" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('431deae8cac442839220c379f321f6c5', 'kesplus_functions_1001', 0, '0', 'kesplus', '{ "zh-CN" : "请输入新名称！", "en-US" : "Please input new name ！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('2fc0ac55d9414d308d746e786dd868e7', 'kesplus_functions_1002', 0, '0', 'kesplus', '{ "zh-CN" : "函数已存在！", "en-US" : "function already exists！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('11221fb95e6e4b14bb013412c0ebb6c5', 'kesplus_functions_1003', 0, '0', 'kesplus', '{ "zh-CN" : "存储过程已存在！", "en-US" : "Procedures already exists！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('797d1b83f2314ee8bb99be168ee82bb4', 'kesplus_functions_1004', 0, '0', 'kesplus', '{ "zh-CN" : "参数[%]不合法，只能包含字母、下划线和数字，且必须以字母或下划线开头！", "en-US" : "Parameter is invalid！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('dc89f36f215848db951f5c3f724f83a7', 'kesplus_generator_1001', 0, '0', 'kesplus', '{ "zh-CN" : "查询参数不能为空！", "en-US" : "select para is not empty！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('4830a7d80fcf446590e79b8e41c31a14', 'kesplus_generator_1003', 0, '0', 'kesplus', '{ "zh-CN" : "请选择删除数据!", "en-US" : "please select delete data!" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('91cbe07a817740de8312c599d424a611', 'kesplus_git_1005', 0, '0', 'kesplus', '{ "zh-CN" : "GIT远程commit失败", "en-US" : "Git commit failed" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('a173f530873e46708f09bf1d522a06a1', 'kesplus_git_1006', 0, '0', 'kesplus', '{ "zh-CN" : "GIT凭证校验失败", "en-US" : "Git credential validation failed" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('1c1bfd57d6e44713856b99801ac281ed', 'kesplus_git_1007', 0, '0', 'kesplus', '{ "zh-CN" : "项目初始化失败", "en-US" : "Project initialization failed" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('1e4bc2ebeb46424086724f84cd931a21', 'kesplus_git_1008', 0, '0', 'kesplus', '{ "zh-CN" : "GIT 初始化失败", "en-US" : "Git initialization failed" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('44fe771bcded4748a898cc195cec7bda', 'kesplus_git_1009', 0, '0', 'kesplus', '{ "zh-CN" : "文件获取失败", "en-US" : "Failed to get file" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('1b961522dbf3460d96917b31edc8a5e3', 'kesplus_git_1010', 0, '0', 'kesplus', '{ "zh-CN" : "GIT地址为空", "en-US" : "Git address is empty" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('f568f32589984b1bb76c99ecac3daa6e', 'kesplus_git_1011', 0, '0', 'kesplus', '{ "zh-CN" : "仓库无此群组", "en-US" : "Git group does not exist" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('9635ac95ceb0476bac9804379b1468cb', 'kesplus_git_1012', 0, '0', 'kesplus', '{ "zh-CN" : "创建应用git push提交失败!", "en-US" : "Create application, Git push failed" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('78fb100bd3b84e3288c72987d917764f', 'kesplus_git_1013', 0, '0', 'kesplus', '{ "zh-CN" : "用户在Git中不存在", "en-US" : "Git user does not exist" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('deb6c52b79fd434aacb0d4fc66f76b84', 'kesplus_git_1014', 0, '0', 'kesplus', '{ "zh-CN" : "获取管理员账号信息和git信息失败", "en-US" : "Failed to get git information" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('41c2757c608e4bd59c425c665f63dbe8', 'kesplus_git_1015', 0, '0', 'kesplus', '{ "zh-CN" : "初始化管理员账号信息和git信息失败", "en-US" : "Failed to initialize git information" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('19a2f21fc442468eb1f22704d7e4d23b', 'kesplus_init_1001', 0, '0', 'kesplus', '{ "zh-CN" : "模块参数不能为空！", "en-US" : "module para is not empty！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('323d23200029494b95028e25c556f42e', 'kesplus_init_1002', 0, '0', 'kesplus', '{ "zh-CN" : "业务表参数不能为空！", "en-US" : "business table is not empty！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('2732fe388cb043b29da64cbdee762e80', 'kesplus_init_1003', 0, '0', 'kesplus', '{ "zh-CN" : "已生成代码！", "en-US" : "already generate code！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('8b8ae9fff4014c24a051c7338729658d', 'kesplus_jobs_1001', 0, '0', 'kesplus', '{ "zh-CN" : "该任务不存在！", "en-US" : "Task is not  exists！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('326cb2ddd3f146308626ae3715bb7120', 'kesplus_jobs_1002', 0, '0', 'kesplus', '{ "zh-CN" : "该目录不存在！", "en-US" : "Diretory is not  exists！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('88d28444779d44428ef53591f1034d53', 'kesplus_jobs_1003', 0, '0', 'kesplus', '{ "zh-CN" : "定时任务目录名称重复！", "en-US" : "Scheduled task diretory repeat！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('c929af2a7b794f46af6a8005ec1ce407', 'kesplus_jobs_1004', 0, '0', 'kesplus', '{ "zh-CN" : "该任务未生效，请先编辑任务内容并生效！", "en-US" : "Task not effect,please edit the content！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('5cdc54b36d1545c9acb277ce6393c6a9', 'kesplus_jobs_1005', 0, '0', 'kesplus', '{ "zh-CN" : "未编辑执行语句！", "en-US" : "Not edit exectue statement！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('290dd1a9ba464f2fba2973b440c9a17e', 'kesplus_jobs_1006', 0, '0', 'kesplus', '{ "zh-CN" : "当前id已存在！", "en-US" : "The current id already exists！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('e37d56c67af14c178fa8dd84ab323be3', 'kesplus_jobs_1007', 0, '0', 'kesplus', '{ "zh-CN" : "任务编码[%]已存在！", "en-US" : "Task code [%] already exists！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('437ef5d8d6b44c4585e1bc62f4f9d14b', 'kesplus_jobs_1008', 0, '0', 'kesplus', '{
  "zh-CN": "该目录不存在！",
  "en-US": "the directory is not exist"
}', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('5ecec25849e24a9cab86b711802d6d3a', 'kesplus_jobs_1009', 0, '0', 'kesplus', '{
  "zh-CN": "当前id不存在！",
  "en-US": "the current id is not exist"
}', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('84b41a82f09e4029813c2674b6df7af8', 'kesplus_jobs_1010', 0, '0', 'kesplus', '{ "zh-CN" : "当前目录下存在数据，不能删除!！", "en-US" : "The directory no data exists ,not delete！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('d1a134db76fb45578f0f24483a09911f', 'kesplus_jobs_1011', 0, '0', 'kesplus', '{ "zh-CN" : "同一层级定时任务和定时任务目录名称不能重复！", "en-US" : "Schedules tasks and scheduled task diretories on the same layer cannot be duplicated！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('3884f297a9d54c5f8b8c42d09772673a', 'kesplus_jobs_1012', 0, '0', 'kesplus', '{ "zh-CN" : "定时任务编码重复！", "en-US" : "Schedules tasks code repeat！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('2a815a7d05264716a0a40d7b36b490d8', 'kesplus_jobs_1013', 0, '0', 'kesplus', '{ "zh-CN" : "该任务不存在！", "en-US" : "The task not exists！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('2a815a7d05264123a0a40d7b36b490d8', 'kesplus_jobs_1015', 0, '0', 'kesplus', '{ "zh-CN" : "执行内容不能为空！", "en-US" : "The task content must not be null！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('6e08f1a18917464985e08e655c0d3ad4', 'kesplus_ldap_1001', 0, '0', 'kesplus', '{ "zh-CN" : "请输入数据！", "en-US" : "Please input data！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('9b16071e67ae4674b5e008581a0acbb1', 'kesplus_ldap_1002', 0, '0', 'kesplus', '{ "zh-CN" : "请选择删除数据！", "en-US" : "Please select delete data！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('d9b0c25721b54721a7ef69004be2bec6', 'kesplus_lock_001', 0, '0', 'kesplus', '{ "zh-CN" : "对象未被您锁定，无法操作，请先获取锁", "en-US" : "The object is not locked by you and cannot be manipulated. Please acquire the lock first." }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('303d69fbaa064b0d9de4e6c849ab3568', 'kesplus_login_1001', 0, '0', 'kesplus', '{ "zh-CN" : "验证码错误", "en-US" : "verification code error" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('23b14f97e8af49609080b385df05dcb2', 'kesplus_login_1002', 0, '0', 'kesplus', '{ "zh-CN" : "用户名不能为空", "en-US" : "the username cannot be null" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('d44dc588f91142248d61a7b042ab11cb', 'kesplus_login_1003', 0, '0', 'kesplus', '{ "zh-CN" : "密码不能为空", "en-US" : "the password cannot be null" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('01506ac83c19487aac94b43d43253d0e', 'kesplus_login_1005', 0, '0', 'kesplus', '{ "zh-CN" : "验证码超时，请刷新", "en-US" : "The verification code times out. Please refresh it." }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('4751bcec0c3240baac878508574c8b1e', 'kesplus_login_1006', 0, '0', 'kesplus', '{ "zh-CN" : "验证码不能为空", "en-US" : "The verification code cannot be empty" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('372820163326458ab7836910f0589204', 'kesplus_login_1007', 0, '0', 'kesplus', '{ "zh-CN" : "密码错误,还有%次机会!", "en-US" : "Wrong password. % more chances" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('1e025f07d39c4888a9b9d8c09daa8b5a', 'kesplus_login_1008', 0, '0', 'kesplus', '{ "zh-CN" : "您多次输入密码错误,账户已锁定,请联系管理员", "en-US" : "The account has been locked.Please contact the administrator" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('f96e3260daa24f07a54ea2e790c019ec', 'kesplus_login_1009', 0, '0', 'kesplus', '{ "zh-CN" : "您的账户已锁定，距解锁还有: %", "en-US" : "Your account is locked. % to unlock" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('965d0810b30b4b68aa91f3f5ddd83640', 'kesplus_login_5009', 0, '0', 'kesplus', '{ "zh-CN" : "用户名或密码错误", "en-US" : "Error incorrect username or password" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('fdfae965152a489aa13347310d13919f', 'kesplus_menu_100', 0, '0', 'kesplus', '{
  "zh-CN": "菜单编码已存在",
  "en-US": "the menu code is already exist"
}', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('43d891d910e64213adeba6abc2f3ca15', 'kesplus_menu_1000', 0, '0', 'kesplus', '{
  "zh-CN": "菜单编码已存在！",
  "en-US": "menu encoding already exists！"
}', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('ea8d12ee82ae467b8afe7d0278ec93b0', 'kesplus_menu_1001', 0, '0', 'kesplus', '{ "zh-CN" : "菜单编码不能为空", "en-US" : "the menu cannot be empty！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('460a3186c4354b1e8c20b253c6f62898', 'kesplus_menu_1002', 0, '0', 'kesplus', '{ "zh-CN" : "上级菜单必须为目录!", "en-US" : "The upper level must be directory!" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('da71d0635c82492bbd80d579c8a8b0e6', 'kesplus_menu_1003', 0, '0', 'kesplus', '{ "zh-CN" : "菜单名称在当前层级重复!", "en-US" : "The menu name repeats at the current level!" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('eb847f662d934a08956cda301efd32f5', 'kesplus_menu_1005', 0, '0', 'kesplus', '{ "zh-CN" : "含有下级菜单的目录不能修改为非目录类型!", "en-US" : "A directory containing a subordinate menu cannot be change to a non-directory type!" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('9f05c58309c74b5a9576e2e18eb468cc', 'kesplus_menu_1006', 0, '0', 'kesplus', '{ "zh-CN" : "缺少模块参数!", "en-US" : "Missing module parameters!" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('191a705bfd184cb6bb0356430cfabd69', 'kesplus_menu_1021', 0, '0', 'kesplus', '{ "zh-CN" : "菜单编号已存在!", "en-US" : "Menu code already exists!" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('b2e381244e8d4f2c9c60f5a5cc98bce5', 'kesplus_module_1000', 0, '0', 'kesplus', '{ "zh-CN" : "模块信息获取失败", "en-US" : "Failed to get module information" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('3773d77cb97a4ebb94090dcdfb7e6d8d', 'kesplus_module_1001', 0, '0', 'kesplus', '{ "zh-CN" : "不允许删除内置模块！", "en-US" : "Deletion of  built-in modules is  not allowed！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('5840a9bc75d54689a4d45a45736ab452', 'kesplus_module_1002', 0, '0', 'kesplus', '{ "zh-CN" : "模块不存在", "en-US" : "the module not exists" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('657dfb66c59a4128b47f1fd0e482273b', 'kesplus_module_1003', 0, '0', 'kesplus', '{ "zh-CN" : "模块ID不能为空", "en-US" : "the module ID cannot be null" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('e470245d1d144db0a2f9f34fa5a9e27a', 'kesplus_module_1004', 0, '0', 'kesplus', '{ "zh-CN" : "模块路径已存在", "en-US" : "the module path already exists" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('6c90408db1004a34bb4c13da97f63f01', 'kesplus_module_1021', 0, '0', 'kesplus', '{ "zh-CN" : "模块路径获取失败", "en-US" : "Failed to get module path" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('a1ed02269c9c4760a6ccd4b64fac33cb', 'kesplus_module_1022', 0, '0', 'kesplus', '{ "zh-CN" : "模块编码不能包含特殊字符！", "en-US" : "Module encoding cannot contain  special characters！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('29c5f240edc8484c834a64e708dab2e6', 'kesplus_module_2003', 0, '0', 'kesplus', '{ "zh-CN" : "模块导出失败", "en-US" : "Module export failed" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('20cb7e3073c946b4a72541cf4ca06e13', 'kesplus_module_2004', 0, '0', 'kesplus', '{ "zh-CN" : "模块导入失败", "en-US" : "Module import failed" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('a3153149b05e4e7b8ffbc5381b9da30f', 'kesplus_module_2005', 0, '0', 'kesplus', '{ "zh-CN" : "请选择模块", "en-US" : "Please select a module" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('947fc8fcb5cb4e3e8cc672d87d0c27c3', 'kesplus_module_2006', 0, '0', 'kesplus', '{ "zh-CN" : "缺少应用参数", "en-US" : "AppID parameter does not exist" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('2e67af0988cc443285268721cd779fef', 'kesplus_module_2007', 0, '0', 'kesplus', '{ "zh-CN" : "模块已存在，请删除后导入", "en-US" : "Module already exists,please delete and import" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('8122848f208a412e81e59b7bd841bb01', 'kesplus_module_2008', 0, '0', 'kesplus', '{
  "zh-CN": "模块编码已经存在",
  "en-US": "Module code already exists"
}', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('71648d1d36c84021874c4ed02a9e7e78', 'kesplus_packages_1001', 0, '0', 'kesplus', '{ "zh-CN" : "ID为null！", "en-US" : "ID is null！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('15430b6eee7c44088941d5c41f5eeac1', 'kesplus_packages_1002', 0, '0', 'kesplus', '{ "zh-CN" : "包内容不存在！", "en-US" : "Package content is  not exists！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('06174401eacb46ee9e86cb42aef203fa', 'kesplus_packages_1003', 0, '0', 'kesplus', '{ "zh-CN" : "请检查脚本是否书写规范，模式名和包名请添加双引号！", "en-US" : "Check whether the script is written properly！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('a1647190c6674d3d8ee14c6509c4869a', 'kesplus_packages_1004', 0, '0', 'kesplus', '{ "zh-CN" : "请输入新包名称！", "en-US" : "Please input new packages name！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('f7db6ef0f4af4474b43ef0904f353cac', 'kesplus_pkg_1000', 0, '0', 'kesplus', '{ "zh-CN" : "名称已存在", "en-US" : "the name has already exists" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('19037f1f56fa4e1ab43e175b6090aaf6', 'kesplus_pkg_1001', 0, '0', 'kesplus', '{ "zh-CN" : "名称不能为空", "en-US" : "the name cannot be null" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('fa75de278208477e897cd89d169a8b88', 'kesplus_pkg_1002', 0, '0', 'kesplus', '{ "zh-CN" : "当前目录下存在数据，不能删除", "en-US" : "the dir was not be allowed to deleted cause data exists in it" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('15a95e925eea4264a84e92fc3ca2b0d7', 'kesplus_pkg_1003', 0, '0', 'kesplus', '{ "zh-CN" : "包语句解析错误", "en-US" : "the package statement parsing error" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('a446e517707944d2b163af89cf88c9a4', 'kesplus_platform_pkg_1004', 0, '0', 'kesplus', '{ "zh-CN" : "错误cron表达式:%", "en-US" : "wrong cron expression:%" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('f6f88e98b2d2420bb5d634ba2e2c0f3e', 'kesplus_platform_pkg_1005', 0, '0', 'kesplus', '{ "zh-CN" : "日历表达式不支持w相关逻辑", "en-US" : "calendar expression not support w expression logic" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('28bec1317956454a95115b800e21a2db', 'kesplus_platform_pkg_1006', 0, '0', 'kesplus', '{ "zh-CN" : "不能设置自己为上级", "en-US" : "cannot be set yourself as your superior" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('36220ff943a240f78144fd62df76527a', 'kesplus_platform_pkg_1007', 0, '0', 'kesplus', '{ "zh-CN" : "当前及下级不能作为自己的上级", "en-US" : "current subordinates cannot be their superiors" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('98056f479b4c42d3a648fe126555e828', 'kesplus_platform_pkg_1008', 0, '0', 'kesplus', '{ "zh-CN" : "上级记录[%]不存在", "en-US" : "superior record [%] not exists" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('41ded9e6ce5c4f83b43c5555b4adc157', 'kesplus_platform_pkg_1009', 0, '0', 'kesplus', '{ "zh-CN" : "未设置查询条件", "en-US" : "not set query condition" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('0e4bbf454289434dabcc8a9f5a206a04', 'kesplus_platform_pkg_1010', 0, '0', 'kesplus', '{ "zh-CN" : "查询条件[%个]和查询值不匹配[%个]", "en-US" : "query condition [%] not matches query values[%]" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('d271413e5f444d39992bca6fbdade11b', 'kesplus_platform_pkg_1011', 0, '0', 'kesplus', '{ "zh-CN" : "未获取到当前用户的部门信息，请先设置部门", "en-US" : "cannot get department information, please set first" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('bd8b1286060f4bbdac99248512477e66', 'kesplus_platform_pkg_1013', 0, '0', 'kesplus', '{ "zh-CN" : "生成select语句失败", "en-US" : "fail to generate select statement" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('bd8b1286060eebbdac99248512477e66', 'kesplus_platform_job_1014', 0, '0', 'kesplus', '{ "zh-CN" : "不支持每秒执行的定时任务，最小时间间隔为10s", "en-US" : "Periodic tasks cannot be executed every second. The minimum interval is 10 seconds" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('fe8bfed34cdb480ab28fce24310ba200', 'kesplus_platform_pkg_1014', 0, '0', 'kesplus', '{ "zh-CN" : "无效的输入参数[%]", "en-US" : "invalid input parameters [%]" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('afee5c7ef6334702aaeac6478574936e', 'kesplus_platform_pkg_1015', 0, '0', 'kesplus', '{ "zh-CN" : "对象[%]不存在", "en-US" : "object [%] not exists" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('94b7794e22364b2696a87be154d03ff6', 'kesplus_platform_pkg_1017', 0, '0', 'kesplus', '{ "zh-CN" : "属性信息不匹配", "en-US" : "the attribute information not matched" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('f13b23282dd44872a028d93435d99a9e', 'kesplus_platform_pkg_1018', 0, '0', 'kesplus', '{ "zh-CN" : "参数输入输出错误", "en-US" : "input or output error" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('8608298191de42b4be20d0c2c5023f77', 'kesplus_platform_pkg_1019', 0, '0', 'kesplus', '{ "zh-CN" : "语句缺少schema", "en-US" : "missing schema for statement" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('d7a21cf0d36e4f3e859b956011046f0d', 'kesplus_platform_pkg_1020', 0, '0', 'kesplus', '{ "zh-CN" : "参数名中不允许带有符号[\"]", "en-US" : "parameter names cannot contain symbols [\"]" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('504657b583bb4dab810a5def9df6f95e', 'kesplus_platform_pkg_1066', 0, '0', 'kesplus', '{ "zh-CN" : "请输入数据", "en-US" : "please input data" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('11e69a03969a4dd5b813a5f66f872c42', 'kesplus_platform_pkg_1067', 0, '0', 'kesplus', '{ "zh-CN" : "请选择数据删除", "en-US" : "please select data to delete" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('ee35d89aae434ed2a48a295b4cfe2d5e', 'kesplus_platform_pkg_1068', 0, '0', 'kesplus', '{ "zh-CN" : "查询参数不能为空", "en-US" : "query param not empty" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('6f80d8c8c13f4b019537edb01a1434dc', 'kesplus_platform_pkg_1069', 0, '0', 'kesplus', '{ "zh-CN" : "% 是 null", "en-US" : "% is null" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('e6d0e4eb85064dad90445fcfd1b4d005', 'kesplus_platform_pkg_1070', 0, '0', 'kesplus', '{ "zh-CN" : "请输入更新数据", "en-US" : "Please enter the update data." }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('bfc0abcc54d641b2a4e39e1415faed40', 'kesplus_platform_pkg_1071', 0, '0', 'kesplus', '{ "zh-CN" : "请输入更新条件", "en-US" : "Please enter the update criteria." }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('06cbba8e12e34e7f93f599fbf3885272', 'kesplus_platform_pkg_1072', 0, '0', 'kesplus', '{ "zh-CN" : "查询结果包含多行记录", "en-US" : "The query result contains multiple records." }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('357085477ec54682927289f77769bb0b', 'kesplus_platform_pkg_app_1033', 0, '0', 'kesplus', '{ "zh-CN" : "appCode不能为空", "en-US" : "app code cannot be empty" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('9df2c4cae50247e2bcca0d10712ae211', 'kesplus_platform_pkg_app_1034', 0, '0', 'kesplus', '{ "zh-CN" : "appName不能为空", "en-US" : "app name cannot be empty" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('265916c7cf8b43c7a16f8c28ff35a32b', 'kesplus_platform_pkg_app_1035', 0, '0', 'kesplus', '{ "zh-CN" : "目录id不能为空", "en-US" : "directory id cannot be empty" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('854d2cc7eb884c41a1d1175bdc8e78d9', 'kesplus_platform_pkg_app_1036', 0, '0', 'kesplus', '{ "zh-CN" : "目录名称不能为空", "en-US" : "directory name cannot be empty" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('ae5b6acf5e6f4bf68ab7a26386d478a0', 'kesplus_platform_pkg_app_1037', 0, '0', 'kesplus', '{ "zh-CN" : "分类id不能为空", "en-US" : "classify id cannot be empty" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('b2877172dc30414aa5911cce066b0de2', 'kesplus_platform_pkg_app_1038', 0, '0', 'kesplus', '{ "zh-CN" : "用户ID[%]已存在", "en-US" : "user id [%] exists" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('dde7e99a4448456990a3a8653c81a7da', 'kesplus_platform_pkg_app_1039', 0, '0', 'kesplus', '{ "zh-CN" : "用户名称[%]已存在", "en-US" : "user name [%] exists" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('bf5539fe535d49678dab2805c267861f', 'kesplus_platform_pkg_app_1040', 0, '0', 'kesplus', '{ "zh-CN" : "应用数据源schema为空", "en-US" : "app datasource schema is empty" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('dfe559d4dda64b82b8170e47daf6bda0', 'kesplus_platform_pkg_app_1041', 0, '0', 'kesplus', '{ "zh-CN" : "更新sysuser失败[%:%]", "en-US" : "failed to update sysuser[%:%]" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('0fda942144224dbc92988dcf225b014e', 'kesplus_platform_pkg_app_1042', 0, '0', 'kesplus', '{ "zh-CN" : "更新gitUser失败[%:%]", "en-US" : "failed to update gituser[%:%]" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('7a8c32765fa74426b7f537e4e8551062', 'kesplus_platform_pkg_app_1043', 0, '0', 'kesplus', '{ "zh-CN" : "更新appUser失败[%:%]", "en-US" : "failed to update appuser[%:%]" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('1a492b355c9d4a7daedd3e208f10886f', 'kesplus_platform_pkg_app_1044', 0, '0', 'kesplus', '{ "zh-CN" : "保存sysuser失败[%:%]", "en-US" : "failed to save sysuser[%:%]" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('325ca980782e495d9d83125e4959563f', 'kesplus_platform_pkg_app_1045', 0, '0', 'kesplus', '{ "zh-CN" : "保存gituser失败[%:%]", "en-US" : "failed to save gituser[%:%]" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('17291ce3f79d4def9ae90fd9a45fbfc0', 'kesplus_platform_pkg_app_1046', 0, '0', 'kesplus', '{ "zh-CN" : "保存appuser失败[%:%]", "en-US" : "failed to save appuser[%:%]" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('27291ce3f79d4def9ae90fd9a45fbfc0', 'kesplus_platform_pkg_app_1047', 0, '0', 'kesplus', '{ "zh-CN" : "会话时长不能小于5分钟，且不能超过10080分钟(7天)", "en-US" : "the session duration cannot exceed 10080 minutes" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('582a32f56ede4f1395c8e4f442147ee3', 'kesplus_platform_pkg_appuser_1047', 0, '0', 'kesplus', '{ "zh-CN" : "初始化appuser失败[%:%]", "en-US" : "failed to init appuser[%:%]" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('c77885685dbf4ceba916e1f87efa8126', 'kesplus_platform_pkg_appuser_1048', 0, '0', 'kesplus', '{ "zh-CN" : "用户已存在", "en-US" : "user exists" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('5c4e86aa78144e638200ca981e12bb87', 'kesplus_platform_pkg_cache_1022', 0, '0', 'kesplus', '{ "zh-CN" : "用户id不能为空", "en-US" : "user id must not be empty" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('85401262cbd940ca8c1db7452e034a7b', 'kesplus_platform_pkg_cache_1023', 0, '0', 'kesplus', '{ "zh-CN" : "RESTful Id不能为空", "en-US" : "RESTful id must not be empty" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('fc4827fb3b834620b4fe1605c3de0861', 'kesplus_platform_pkg_conf_1024', 0, '0', 'kesplus', '{ "zh-CN" : "该配置模板不存在[%]", "en-US" : "this configuration template not exists" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('fe0109fd175a43f3aecfdeedd18c8fa1', 'kesplus_platform_pkg_conf_1025', 0, '0', 'kesplus', '{ "zh-CN" : "不允许删除平台配置", "en-US" : "platform configuration cannot be deleted" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('48b3e3fc5f0a44058d9c78415ec8b345', 'kesplus_platform_pkg_conf_1026', 0, '0', 'kesplus', '{ "zh-CN" : "该配置不存在[%]", "en-US" : "configuration [%] not exists" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('a70b07fef9bd4fabbd06a09b0b9ee159', 'kesplus_platform_pkg_conf_1027', 0, '0', 'kesplus', '{ "zh-CN" : "非法配置参数[%]", "en-US" : "illegal configuration parameter [%]" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('cb7336a6ea3d46c58b6029dd4b48d941', 'kesplus_platform_pkg_conf_1028', 0, '0', 'kesplus', '{ "zh-CN" : "ID已存在", "en-US" : "id exists" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('d9dca82f8b7646d591e540443d0bac9d', 'kesplus_platform_pkg_conf_1029', 0, '0', 'kesplus', '{ "zh-CN" : "ID不存在", "en-US" : "id not exists" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('239fdb1182a44d16b25017b0ca07f44b', 'kesplus_platform_pkg_conf_1030', 0, '0', 'kesplus', '{ "zh-CN" : "配置编码已存在", "en-US" : "configuration code exists" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('9ef682a1850b4c08b00f6270fa4ab97a', 'kesplus_platform_pkg_conf_1031', 0, '0', 'kesplus', '{ "zh-CN" : "当前作用域下配置已存在", "en-US" : "configuration in the current scope already exists" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('3f49f1f4012a424ba2f6570529c200e5', 'kesplus_platform_pkg_conf_1032', 0, '0', 'kesplus', '{ "zh-CN" : "配置key不为null", "en-US" : "configuration key is not null" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('f13c61c601d04368a542f5d2bc785151', 'kesplus_platform_pkg_git_1049', 0, '0', 'kesplus', '{ "zh-CN" : "git仓库已存在", "en-US" : "git repository exists" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('bcdfa67fee93406c8e8758d25cab96a7', 'kesplus_platform_pkg_git_1050', 0, '0', 'kesplus', '{ "zh-CN" : "保存失败", "en-US" : "failed to save" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('f094e2c8cdfd4dc89ebac62f71cbc291', 'kesplus_platform_pkg_gituser_1051', 0, '0', 'kesplus', '{ "zh-CN" : "该用户名存在", "en-US" : "username exists" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('e780b429f82048d9bb7ad5671a889839', 'kesplus_platform_pkg_logs_1052', 0, '0', 'kesplus', '{ "zh-CN" : "解析json失败", "en-US" : "paring json failed" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('ddface19b30b486fb59f45c786de4988', 'kesplus_platform_pkg_logs_1053', 0, '0', 'kesplus', '{ "zh-CN" : "解析url失败", "en-US" : "parsing url failed" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('9731715c7557495cbcd75c0d5396e6a2', 'kesplus_platform_pkg_logs_1054', 0, '0', 'kesplus', '{ "zh-CN" : "日志类型不能为空", "en-US" : "log type cannot be empty" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('768db25d8c0546a3891843d84e656ad9', 'kesplus_platform_pkg_market_1055', 0, '0', 'kesplus', '{ "zh-CN" : "数据不为空", "en-US" : "data cannot be empty" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('faa30b6934d446949219def32bd922a7', 'kesplus_platform_pkg_member_1056', 0, '0', 'kesplus', '{ "zh-CN" : "该用户名已存在", "en-US" : "user name exists" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('5a26b923103c4f40b20664af2bd0d61d', 'kesplus_platform_pkg_member_1057', 0, '0', 'kesplus', '{ "zh-CN" : "非管理员用户不能修改他人信息", "en-US" : "non-administrator users cannot modify information of other people" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('d2b89805d5af48a0ad92eceb4b4c1fdb', 'kesplus_platform_pkg_member_1058', 0, '0', 'kesplus', '{ "zh-CN" : "不允许修改用户名信息", "en-US" : "the user name cannot be changed" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('8ce2277d88b340c08f34e654e7bca1aa', 'kesplus_platform_pkg_member_1059', 0, '0', 'kesplus', '{ "zh-CN" : "非管理员用户不能修改成员用户状态", "en-US" : "non-administrator users cannot change the status of member users" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('a2d9c60370a247b4b180cd34a2b99e39', 'kesplus_platform_pkg_member_1060', 0, '0', 'kesplus', '{ "zh-CN" : "成员用户无法修改自己的状态", "en-US" : "members cannot modify their own state" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('6869064221a14e88b877b9df6af7d1b5', 'kesplus_platform_pkg_member_1061', 0, '0', 'kesplus', '{ "zh-CN" : "该人员为应用的管理角色，无法将应用与该人员取消绑定", "en-US" : "the application cannot be unbound from the user because the user is an administrator" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('8dec3bee187a43428b76d9d51e485824', 'kesplus_platform_pkg_member_1062', 0, '0', 'kesplus', '{ "zh-CN" : "该人员为应用的管理角色，无法删除该人员", "en-US" : "this person is an application administrator and cannot be deleted" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('8dec3bee187a43428b76d9d51e485825', 'kesplus_platform_pkg_member_1063', 0, '0', 'kesplus', '{ "zh-CN" : "平台管理员不允许修改", "en-US" : "you are not allowed to edit the administrator" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('cba6a7582a6e4835bb3fda92fb47408f', 'kesplus_platform_pkg_statics_1063', 0, '0', 'kesplus', '{ "zh-CN" : "请输入api路径", "en-US" : "please input API path" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('ad78f8b7f8f3413daa2a433ede8f39e5', 'kesplus_platform_SYSTEM_1064', 0, '0', 'kesplus', '{ "zh-CN" : "系统Api不可新增", "en-US" : "system api cannot be added" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('13f7cab3bba043ea95cd83b5fe495417', 'kesplus_platform_SYSTEM_1065', 0, '0', 'kesplus', '{ "zh-CN" : "系统Api不可编辑", "en-US" : "system api cannot be editable" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('05a0a9328b324f3ba13798630d8c08aa', 'kesplus_policy_1001', 0, '0', 'kesplus', '{ "zh-CN" : "未选择业务表!", "en-US" : "No business table is selected!" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('a746c4e47fa64c11adf2360dec706511', 'kesplus_policy_1002', 0, '0', 'kesplus', '{ "zh-CN" : "上级必须为目录!", "en-US" : "The upper level must be directory!" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('487397392b814be2832ebd8a6abbd1cd', 'kesplus_policy_1003', 0, '0', 'kesplus', '{ "zh-CN" : "不允许跨模块移动!", "en-US" : "Cross-module movement is not allowed!" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('93a233f9882c49c6be9cb0acd5b75264', 'kesplus_policy_1005', 0, '0', 'kesplus', '{ "zh-CN" : "缺少参数:[%]!", "en-US" : "Missing parameters:[%]!" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('a71641021a21499ba8d8444dc60c8355', 'kesplus_policy_1006', 0, '0', 'kesplus', '{ "zh-CN" : "缺少模块参数!", "en-US" : "Missing module parameters!" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('b2d9e25ec68b4e10ae5677a88f9af34f', 'kesplus_receive_500', 0, '0', 'kesplus', '{ "zh-CN" : "缺少必要的接口参数", "en-US" : "Missing parameter" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('df2ad9e28e4e4556bbe17a4c13f27475', 'kesplus_rest_1001', 0, '0', 'kesplus', '{ "zh-CN" : "API不存在！", "en-US" : "The API does not exist！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('cbd457b43c3541db8c05222efe348ae8', 'kesplus_rest_1002', 0, '0', 'kesplus', '{ "zh-CN" : "API版本号[%]已存在，请重新输入！", "en-US" : "API version number [%] already exist,pelase re-enter it！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('8e6c43063baa45508bb62b3e87e63612', 'kesplus_restful_1000', 0, '0', 'kesplus', '{ "zh-CN" : "系统API不可编辑", "en-US" : "not allowed to edit the system apis" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('f44af73a9d0741058ab3cf6500cca7d7', 'kesplus_restful_1001', 0, '0', 'kesplus', '{ "zh-CN" : "名称已存在", "en-US" : "the name has already exists" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('01729fd2a1914941aa29f269c012ffd6', 'kesplus_restful_1002', 0, '0', 'kesplus', '{ "zh-CN" : "当前目录下存在数据，不能删除", "en-US" : "the dir was not be allowed to deleted cause data exists in it" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('e5bfd5d0ba854e13a88bd0554e44c3e3', 'kesplus_restful_1003', 0, '0', 'kesplus', '{ "zh-CN" : "API路径不能为空", "en-US" : "the API path cannot be null" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('f4916fc532ab48b6a9c372d01cb08cbd', 'kesplus_restful_1004', 0, '0', 'kesplus', '{ "zh-CN" : "API已存在", "en-US" : "the API has already exists" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('b16e24c2cf9e4a8283244f551f3277ba', 'kesplus_restful_1005', 0, '0', 'kesplus', '{ "zh-CN" : "APIID不能为空", "en-US" : "the APIID cannot be null" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('391b27249ab049b5827e13d67421329f', 'kesplus_restful_1006', 0, '0', 'kesplus', '{ "zh-CN" : "名称不能为空", "en-US" : "the name cannot be null" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('c3d508fcce4c4f9788497e6aaf511fee', 'kesplus_restful_500', 0, '0', 'kesplus', '{ "zh-CN" : "返回结果格式错误，请检查该请求的api配置", "en-US" : "Return format error,please check API config" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('ea3da218db154f2fbc5211412f90f0c5', 'kesplus_review_500', 0, '0', 'kesplus', '{ "zh-CN" : "项目预览失败", "en-US" : "App preview failed" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('3b913a9ba6a54b6096c3e2eeba8922c9', 'kesplus_role_1001', 0, '0', 'kesplus', '{ "zh-CN" : "同一层级角色名称和角色目录不能重复!", "en-US" : "The role name and role directory of the same level cannot be the same!" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('b2b298a42d0e4b36bc9faf7f8b8d0009', 'kesplus_role_1002', 0, '0', 'kesplus', '{ "zh-CN" : "上级必须为目录!", "en-US" : "The upper level must be directory!" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('5fd22452fb9944a9911ed4b06a9e9601', 'kesplus_role_1003', 0, '0', 'kesplus', '{ "zh-CN" : "角色名称已存在!", "en-US" : "The role name already exists!" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('d185406cab554f0e93643964e533f515', 'kesplus_role_1004', 0, '0', 'kesplus', '{ "zh-CN" : "角色已存在!", "en-US" : "The role already exists!" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('98d9d6935e3f4b18a48e59d5f216cb99', 'kesplus_role_1005', 0, '0', 'kesplus', '{ "zh-CN" : "不允许操作内置角色!", "en-US" : "Cannot manipulate built-in roles!" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('c31c6e6240884a70b5394f2164158888', 'kesplus_role_1006', 0, '0', 'kesplus', '{ "zh-CN" : "不能对目录进行授权操作!", "en-US" : "Cannot authorize a directory!" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('8243fe01c62e471385f39e0b2f064717', 'kesplus_role_1007', 0, '0', 'kesplus', '{ "zh-CN" : "该角色已关联用户，请先解除关联!", "en-US" : "The role has been associated with a user.Disassociate the role first!" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('afd1dfe9b4ae4c54ba46a0c73eb804f1', 'kesplus_role_1008', 0, '0', 'kesplus', '{ "zh-CN" : "角色不存在!", "en-US" : "Role does not exist!" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('11b2b2ca6e634f4a9081f8cee959fe9f', 'kesplus_role_1009', 0, '0', 'kesplus', '{ "zh-CN" : "请先删除子级数据!", "en-US" : "Delete the child data first!" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('1c1c41168d9248e187efb3a5c0c3d44e', 'kesplus_routeinfo_1001', 0, '0', 'kesplus', '{ "zh-CN" : "该服务已被使用！", "en-US" : "The service has already been used！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('0b799f0aebfe41a18646c95d44536a66', 'kesplus_router_1000', 0, '0', 'kesplus', '{ "zh-CN" : "非法的模块编码[%]", "en-US" : "the module code [%] is not allowed" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('93fc1dfd93294b98b018a05e0b175228', 'kesplus_router_1001', 0, '0', 'kesplus', '{ "zh-CN" : "禁止开发端登陆", "en-US" : "login from vscode client is forbidden" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('fe610f627772484583e27483afe818f9', 'kesplus_router_1002', 0, '0', 'kesplus', '{ "zh-CN" : "禁止开发端访问业务端接口", "en-US" : "prevents developers from accessing the business interface" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('e93ed0c32d184c96b8bc9f3f2e5fea93', 'kesplus_router_1003', 0, '0', 'kesplus', '{ "zh-CN" : "禁止业务端访问开发端接口", "en-US" : "disable service personnel from accessing development interface" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('5a4bdb1d804a4567890e6dbfe14b5229', 'kesplus_router_1004', 0, '0', 'kesplus', '{ "zh-CN" : "查询当前用户失败", "en-US" : "failed to find the user" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('c00753bde0f040b291e027cd6fbb156c', 'kesplus_router_1005', 0, '0', 'kesplus', '{ "zh-CN" : "单点token校验失败", "en-US" : "failed to verify the sso token" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('13aa3672d70549729115fa60585c759b', 'kesplus_router_1006', 0, '0', 'kesplus', '{ "zh-CN" : "数据加密失败", "en-US" : "failed to encrypt the data " }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('6b15b70a32ec4e82a55d4bef110acb12', 'kesplus_router_1007', 0, '0', 'kesplus', '{ "zh-CN" : "应用TOKEN加密因子未配置", "en-US" : "the secret of the application token is not configured" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('5b892552ce614606831cea0d3187fa31', 'kesplus_router_1008', 0, '0', 'kesplus', '{ "zh-CN" : "平台TOKEN加密因子未配置", "en-US" : "the secret of the platform token is not configured" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('6c6f4fb9c1764bd5959875f3d4b6cb82', 'kesplus_router_1009', 0, '0', 'kesplus', '{ "zh-CN" : "函数/过程[%]解析失败", "en-US" : "failed to analysis the proc/fun [%]" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('9e60d329710740a3bc2326ff62505eb1', 'kesplus_router_1010', 0, '0', 'kesplus', '{ "zh-CN" : "该函数/过程[%]不存在", "en-US" : "the proc/fun [%] does not exist" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('cfa141f023de4754a4ceabfd9145d3af', 'kesplus_router_1011', 0, '0', 'kesplus', '{ "zh-CN" : "配置错误：%", "en-US" : "erro configuration:%" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('3444d5fbaba24849af1d4a13070026f7', 'kesplus_router_1012', 0, '0', 'kesplus', '{ "zh-CN" : "参数[%]类型未定义", "en-US" : "the type of the param [%] is undefined" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('c7b14daae21d414e8977a5b15edbf127', 'kesplus_router_1013', 0, '0', 'kesplus', '{ "zh-CN" : "不符合要求的数据库名称[%]", "en-US" : "the database name [%] is incorrect" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('7b48c6a06fc340ad8493338316d2f393', 'kesplus_router_1014', 0, '0', 'kesplus', '{ "zh-CN" : "用户名不能为空", "en-US" : "username cannot be null" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('7e563e7077cc4f6a90971eb565034e66', 'kesplus_router_1015', 0, '0', 'kesplus', '{ "zh-CN" : "生成TOKEN参数错误，生成失败", "en-US" : "failed to create a token" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('4330927fd55948e9817775f6a97c9aca', 'kesplus_router_1016', 0, '0', 'kesplus', '{ "zh-CN" : "用户ID不能为空", "en-US" : "userid cannot be null" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('86dbe64a8d4d451f8c1c1d58a038a282', 'kesplus_router_2001', 0, '0', 'kesplus', '{ "zh-CN" : "不支持复杂SQL中调用FUNCTION", "en-US" : "cannot execute complex SQL statement block which contains FUNCTION." }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('950e04028ceb450ba0f369be1de668f4', 'kesplus_router_2002', 0, '0', 'kesplus', '{ "zh-CN" : "缺少必要的参数[%]", "en-US" : "missing required param。" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('892e5a69fb52400b88aa991f5b8899a6', 'kesplus_router_2003', 0, '0', 'kesplus', '{ "zh-CN" : "解析存储过程/函数名称失败", "en-US" : "failed to analysis the name of FUNCTION/PROCEDURE." }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('89bcffa05bbc4a6baa91e4f15f6958b0', 'kesplus_router_2004', 0, '0', 'kesplus', '{ "zh-CN" : "未查询到定义的函数/存储过程，请检查函数/存储过程名称和参数是否正确", "en-US" : "cannot find the FUNCTION/PROCEDURE.please check the name and the args." }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('8da1674b785c43c79eeb39bf205af8c4', 'kesplus_router_2005', 0, '0', 'kesplus', '{ "zh-CN" : null, "en-US" : null }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('e9d0ab71daca46a1a0e3cf54a5edcb2e', 'kesplus_router_2006', 0, '0', 'kesplus', '{ "zh-CN" : "SQL获取数据失败", "en-US" : "SQL EXECUTE FAILD" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('b70b873effad4ddf934e9e48c08471ac', 'kesplus_router_3001', 0, '0', 'kesplus', '{ "zh-CN" : "数据查询失败", "en-US" : "QUERY NO ROWS" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('3b157844c0bd40338e2b4dde5e4e2669', 'kesplus_router_301', 0, '0', 'kesplus', '{ "zh-CN" : "请求地址不存在，请联系管理员", "en-US" : "For this url, you does not configure an api。" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('0540c4e06fe24d049ba7031719b42ce5', 'kesplus_serverinfo_1001', 0, '0', 'kesplus', '{ "zh-CN" : "该IP和端口的服务已存在！", "en-US" : "ip and service port has existsed！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('0e84f74c20244b6cb0a7d04f3c671682', 'kesplus_serverinfo_1002', 0, '0', 'kesplus', '{ "zh-CN" : "当前服务器被路由使用，请先删除路由信息！", "en-US" : "the current service is used by a route ,delete the route information first！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('194f032dcd214da8938b6da46f00e974', 'kesplus_service_001', 0, '0', 'kesplus', '{ "zh-CN" : "源服务非正常状态无法切机，请刷新重试", "en-US" : "The source service is not in a normal state and cannot be cutting machine. Please refresh and try again" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('cc533e665aa44d45b8fecc5dc91548a9', 'kesplus_service_002', 0, '0', 'kesplus', '{ "zh-CN" : "目标服务非正常状态无法切机，请刷新重试", "en-US" : "The target service is not in a normal state and cannot be cutting machine. Please refresh and try again" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('f352d78a2cbd481d9c8e47a5ec2d21f1', 'kesplus_service_003', 0, '0', 'kesplus', '{ "zh-CN" : "源服务状态不是切机状态，请刷新重试", "en-US" : "The source service is not in a cutting machine state. Please refresh and try again" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('4c45e6b7c5ab4fcab0745e305eaa4592', 'kesplus_service_004', 0, '0', 'kesplus', '{ "zh-CN" : "数据库链路不存在，无法进行操作", "zh-CN" : "服务信息不存在，请刷新重试", "en-US" : "Service information does not exist. Please refresh and try again" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('c8f0a946cb384d97ab07b7312bbcc089', 'kesplus_service_005', 0, '0', 'kesplus', '{
  "zh-CN": "数据库链接不存在，无法进行操作",
  "en-US": "The database link does not exist and cannot be operated"
}', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('d51caf54774e4d26b0a1ef306cef4cb8', 'kesplus_service_006', 0, '0', 'kesplus', '{
  "zh-CN": "数据库不存在",
  "en-US": "The database does not exist"
}', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('b72f386dd1484c249150a5e2e8678e71', 'kesplus_sqledit_1001', 0, '0', 'kesplus', '{ "zh-CN" : "没有找到对应的节点类型！", "en-US" : "No corresponding node data found！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('001cf14b6b434df39707d1f19fa1dc8b', 'kesplus_sqledit_1002', 0, '0', 'kesplus', '{ "zh-CN" : "当前对象[%]已被锁定，请刷新页面！", "en-US" : "The Current Object [%] is locked,please refresh the page！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('ed038717015443b79a187b29c8bc9321', 'kesplus_system_1000', 0, '0', 'kesplus', '{ "zh-CN" : "用户角色不能为空", "en-US" : "the user role cannot be null" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('52209493b5de43aa9c3626a1e17ec37d', 'kesplus_system_1001', 0, '0', 'kesplus', '{ "zh-CN" : "未选择添加的模块", "en-US" : "module is needed" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('e52867cd6b9f40ff904f498fc8637f45', 'kesplus_system_1002', 0, '0', 'kesplus', '{ "zh-CN" : "请勿重复初始化应用数据", "en-US" : "cannot init the application data repeated" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('21cd28c17c8043f1b4d37742bc8bedf0', 'kesplus_sysuser_1000', 0, '0', 'kesplus', '{ "zh-CN" : "该成员已存在", "en-US" : "the member user is exist" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('681c20b5188145cd96e5f828cba3d9c9', 'kesplus_sysuser_1002', 0, '0', 'kesplus', '{ "zh-CN" : "请先在关联应用中删除", "en-US" : "delete it in application first" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('af7c533ccf7d41c4b99702d0c62f10be', 'kesplus_sysuser_1003', 0, '0', 'kesplus', '{ "zh-CN" : "请先删除git账号", "en-US" : "delete the git account first" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('6e62afe751b94666803b87174fabff91', 'kesplus_sysuser_1004', 0, '0', 'kesplus', '{ "zh-CN" : "请输入旧密码", "en-US" : "please entry the old password" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('f643d888ea1746d9839b78139aca9d34', 'kesplus_sysuser_1005', 0, '0', 'kesplus', '{ "zh-CN" : "必须包含大小写字母、数字和特殊字符，且长度至少8位", "en-US" : "the value must contain uppercase and lowercase letters,digits and special characters and cannot be less than 8 characters in length" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('98ec024e5f0648fab8c037ea9ed382bd', 'kesplus_sysuser_1006', 0, '0', 'kesplus', '{ "zh-CN" : "旧密码不正确", "en-US" : "old error incorrect" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('97b2ef55a72f4c83bb37968f9960a69b', 'kesplus_sysuser_1007', 0, '0', 'kesplus', '{ "zh-CN" : "两次输入密码不一致", "en-US" : "the two passwords are inconsistent" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('dac75e19f9d746c9bb0e785bb59f1ad7', 'kesplus_sysuser_1008', 0, '0', 'kesplus', '{ "zh-CN" : "禁止开发端登陆", "en-US" : "login from vscode client is forbidden" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('758c33b56ae9401ea0dd07cbf133e2ed', 'kesplus_sysuser_1009', 0, '0', 'kesplus', '{ "zh-CN" : "操作人id不能为空", "en-US" : "userid cannot be null" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('a8b20c70d28043b3985e61363224199f', 'kesplus_sysuser_1010', 0, '0', 'kesplus', '{ "zh-CN" : "该用户已被管理员禁用", "en-US" : "the user is disabled" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('1f8cafccd6eb4da381e0b6e1b662cb2e', 'kesplus_sysversion_1001', 0, '0', 'kesplus', '{ "zh-CN" : "该id[%]已存在！", "en-US" : "Id has exists！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('81bf7cf7b9484c3b88b450637dcb5a46', 'kesplus_sysversion_1002', 0, '0', 'kesplus', '{ "zh-CN" : "该版本编号[%]已存在！", "en-US" : "Version code has exists！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('132f5d53e66343629ae0bba669a975fa', 'kesplus_tables_1000', 0, '0', 'kesplus', '{ "zh-CN" : "无法解析表名", "en-US" : "Unable to resolve table name" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('7f48221f3dc4446e83f7e43e11e8c9f3', 'kesplus_tables_1001', 0, '0', 'kesplus', '{ "zh-CN" : "表名已存在", "en-US" : "Table name already exists" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('3dd580e4261d42429262197aa11e4d91', 'kesplus_tables_1002', 0, '0', 'kesplus', '{ "zh-CN" : "当前目录下存在数据，不能删除", "en-US" : "the dir was not be allowed to deleted cause data exists in it" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('f9ca043baa7548a79bf8f700a01c8ebb', 'kesplus_tables_1003', 0, '0', 'kesplus', '{ "zh-CN" : "表ID不能为空", "en-US" : "table ID cannot be null" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('c2bde1a632bd494081ac9ace1675da9d', 'kesplus_tables_1004', 0, '0', 'kesplus', '{ "zh-CN" : "视图ID不能为空", "en-US" : "view ID cannot be null" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('93a4278cdc5d4d5c8e9af193788d431d', 'kesplus_tables_1005', 0, '0', 'kesplus', '{ "zh-CN" : "约束条件不能为空", "en-US" : "Constraint condition cannot be empty" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('b39409392aab4536b73b2b30972a4816', 'kesplus_tables_1006', 0, '0', 'kesplus', '{ "zh-CN" : "非法的建表语句", "en-US" : "Illegal table creation statement" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('db84c3a4b16d4adc872808f2f1d5b04d', 'kesplus_tables_1007', 0, '0', 'kesplus', '{ "zh-CN" : "不能同时创建多张表", "en-US" : "Cannot create multiple tables simultaneously" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('256960bd8d5247d69668993d0c2252ae', 'kesplus_tables_1008', 0, '0', 'kesplus', '{ "zh-CN" : "不能同时操作不同的表", "en-US" : "Cannot operate multiple tables simultaneously" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('b9c493101eab43cfbfecbda8f23cb0ea', 'kesplus_tables_1009', 0, '0', 'kesplus', '{ "zh-CN" : "不支持的操作类型", "en-US" : "Unsupported operation type" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('350db261ac984a4dba2813a0078d13ac', 'kesplus_tables_1010', 0, '0', 'kesplus', '{ "zh-CN" : "不支持的分区类型", "en-US" : "Unsupported partition type" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('38d70b07fbaf43edbd9fee8ac17aa026', 'kesplus_tables_1011', 0, '0', 'kesplus', '{ "zh-CN" : "schemaName参数为空！", "en-US" : "SchemaName is null！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('3e8e3d46802f4bb684b0cdf62f98084f', 'kesplus_tables_1012', 0, '0', 'kesplus', '{ "zh-CN" : "tableName参数为空！", "en-US" : "tableName  is  null！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('069453c362624365a7d7f145e050b183', 'kesplus_tables_1013', 0, '0', 'kesplus', '{ "zh-CN" : "policyName参数为空!", "en-US" : "policyName is null！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('58d3bb400a2d4e3faece02eb01817904', 'kesplus_tables_1014', 0, '0', 'kesplus', '{ "zh-CN" : "dataBaseName参数为空！", "en-US" : "dataBaseName is null！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('4e40fe1fb91345af86ef44eac9383e8f', 'kesplus_tables_1015', 0, '0', 'kesplus', '{ "zh-CN" : "constraintName参数为空！", "en-US" : "constraintName is  null！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('d38969cc410d40fa9a574d7e2a7eccb6', 'kesplus_tables_1016', 0, '0', 'kesplus', '{ "zh-CN" : "tableOid参数为空！", "en-US" : "tableOid is  null！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('78398de3f4d84a0fa3956443d6560151', 'kesplus_tables_1017', 0, '0', 'kesplus', '{ "zh-CN" : "indexOid参数为空！", "en-US" : "indexOid is null！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('44dbb77f1cf74681b452269823d2acdd', 'kesplus_tables_1018', 0, '0', 'kesplus', '{ "zh-CN" : "partition参数为空！", "en-US" : "partition is null！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('1ea7857f7c1d4dc1b5ff762666547196', 'kesplus_tables_1019', 0, '0', 'kesplus', '{ "zh-CN" : "name参数为空！", "en-US" : "name is null！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('472e8f14c331412eb2b28a8b1a48f0c6', 'kesplus_tables_1020', 0, '0', 'kesplus', '{ "zh-CN" : "tableSchema参数为空！", "en-US" : "tableSchema is  null！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('31cbfce0dd414a19a72509d1cfe52b41', 'kesplus_tables_1021', 0, '0', 'kesplus', '{ "zh-CN" : "请输入新表名称！", "en-US" : "Please input new table name！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('7393bd1a1ce646d9b575a27761e2721b', 'kesplus_tables_1022', 0, '0', 'kesplus', '{ "zh-CN" : "indexMethod参数为空！", "en-US" : "indexMethod is  null！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('8f29a03ba0344931b0a4bac294dc4766', 'kesplus_tables_1023', 0, '0', 'kesplus', '{ "zh-CN" : "同一层级表目录和表对象名称不能重复！", "en-US" : "The directory and object names of the same level table cannot be the same！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('a3e5ef45dce0416cb942031696d6bff5', 'kesplus_tables_1024', 0, '0', 'kesplus', '{ "zh-CN" : "表名必须以小写英文字母开头，只能由小写英文字母、数字和单下划线组成！", "en-US" : "The table name must start with a lowercase letter,consisting of lowercase letters,numbers,and underline！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('fd7cb0fbae764ded97750926c01c963b', 'kesplus_tables_1025', 0, '0', 'kesplus', '{ "zh-CN" : "表对象名已经存在，请重新输入！", "en-US" : "The table name already exists！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('4ba284b8c2ed4f0ab5e9fb0c8d0c63b9', 'kesplus_tables_1026', 0, '0', 'kesplus', '{ "zh-CN" : "建表时缺少id字段！", "en-US" : "Missing Id field when createing table！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('2237a5ff0d064cdbaf26382862988d32', 'kesplus_tables_1027', 0, '0', 'kesplus', '{ "zh-CN" : "建表时缺少dept_id字段！", "en-US" : "Missing DeptId field when createing table！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('7669256610654bbc89deacac5bcf6c4f', 'kesplus_tables_1028', 0, '0', 'kesplus', '{ "zh-CN" : "建表时缺少module_code字段！", "en-US" : "Missing ModuleCode field when createing table！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('b53904c0d8cd4d148c7305b136228892', 'kesplus_tables_1029', 0, '0', 'kesplus', '{ "zh-CN" : "表名称[%]已存在！", "en-US" : "Table name [%] already exitst！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('05cb7528fc8b4e5098bc69ae859106c0', 'kesplus_tables_1030', 0, '0', 'kesplus', '{ "zh-CN" : "表的对象类型为空！", "en-US" : "Table type is empty！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('1b914e1da0cf402385235e37e993f773', 'kesplus_tables_1031', 0, '0', 'kesplus', '{ "zh-CN" : "查询参数不能为空！", "en-US" : "Query parameters cannot be empty！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('be02a56bae5144508de9867b74d17d82', 'kesplus_tables_1032', 0, '0', 'kesplus', '{ "zh-CN" : "获取表信息失败！", "en-US" : "Failed to obtain table information！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('8a9d114ff0cc486884484def602a57e5', 'kesplus_tables_1033', 0, '0', 'kesplus', '{ "zh-CN" : "表对象缺少主键列！", "en-US" : "Table object missing primary key column！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('4491e39415554cbd94db5df38f718cc2', 'kesplus_tables_1034', 0, '0', 'kesplus', '{ "zh-CN" : "表的主键类型错误！", "en-US" : "The primary key type of the table object is incorrect！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('14c8ddeee30248f98e8462542909ee1a', 'kesplus_tables_1035', 0, '0', 'kesplus', '{ "zh-CN" : "请输入数据！", "en-US" : "Please enter data！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('cbd958e7ce304713aaf9a6cc487050ab', 'kesplus_tables_1036', 0, '0', 'kesplus', '{ "zh-CN" : "请选择要删除的数据！", "en-US" : "Please select the data to be deleted！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('da7bb4a0fa1d4c6a8182691bec638a37', 'kesplus_template_1001', 0, '0', 'kesplus', '{ "zh-CN" : "请选择模板！", "en-US" : "Please select template！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('9156a17825174aac81edbe18c06304e6', 'kesplus_template_1002', 0, '0', 'kesplus', '{ "zh-CN" : "模板数据不存在！", "en-US" : "The template does not exist！" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('ab9236570f2c4901a7ea798902453358', 'kesplus_token_401', 0, '0', 'kesplus', '{ "zh-CN" : "未登录", "en-US" : "PLEASE LOGIN" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('7422c6a224aa4ebda1f6bdcc8f591245', 'kesplus_token_601', 0, '0', 'kesplus', '{ "zh-CN" : "登录超时，请重新登录", "en-US" : "token expired，please login agin。" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('e98ffc499fff482394d1a77abc42ee1c', 'kesplus_token_603', 0, '0', 'kesplus', '{ "zh-CN" : "会话验证未通过，请重新登录", "en-US" : "illegal token,please login again" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('74c561cfe107432e8c69aea0193493dc', 'kesplus_tree_1000', 0, '0', 'kesplus', '{ "zh-CN" : "节点不能作为自己的上级节点存在", "en-US" : "one node cannot be its own parent node" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('9900a1bab13844cdaae91368a6b50931', 'kesplus_tree_1001', 0, '0', 'kesplus', '{
  "zh-CN": "菜单类型和对象类型不能为空!",
  "en-US": "Menu types and object types cannot be null!"
}', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('b23586b34a544e869f183536751a9075', 'kesplus_tree_1002', 0, '0', 'kesplus', '{
  "zh-CN": "缺少主键参数",
  "en-US": "Missing primary key parameter!"
}', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('cdf96e3df7c34f1c864c4d80978b6d76', 'kesplus_tree_1003', 0, '0', 'kesplus', '{
  "zh-CN": "请先删除子节点！",
  "en-US": "Delete the data of the child node first!"
}', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('d2603804a8c74e1d9b42175a00ab1e3e', 'kesplus_tree_1004', 0, '0', 'kesplus', '{
  "zh-CN": "目录 [%] 已经存在！",
  "en-US": "Directory [%] already exists!"
}', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('367e182a18f94217ac6d88a1e2b6c4bf', 'kesplus_tree_1005', 0, '0', 'kesplus', '{
  "zh-CN": "上级目录 [%] 不存在！",
  "en-US": "The parent folder [%] does not exist!"
}', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('47603fed990e432c9839eae71740e6bc', 'kesplus_tree_1006', 0, '0', 'kesplus', '{
  "zh-CN": "最大级别为7",
  "en-US": "The maximum level is 7!"
}', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('8e00c4deb6f645c79c89654592ebbebf', 'kesplus_tree_1007', 0, '0', 'kesplus', '{
  "zh-CN": "缺少上级ID",
  "en-US": "Missing parent Id!"
}', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('95eb3ee581a64db3ad8a8770fc028589', 'kesplus_tree_1008', 0, '0', 'kesplus', '{
  "zh-CN": "缺少模块信息！",
  "en-US": "Missing module info!"
}', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('e9cf0b89a6b344bf863bda51ce54c883', 'kesplus_tree_1009', 0, '0', 'kesplus', '{
  "zh-CN": "根目录不能移动！",
  "en-US": "The original directory cannot be moved!"
}', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('ddbe372f68b342cf9fdb6f525e53fda0', 'kesplus_tree_1010', 0, '0', 'kesplus', '{
  "zh-CN": "上级目录不存在！",
  "en-US": "The upper-level directory does not exists!"
}', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('a65621a7abdd48b9853441732e6da952', 'kesplus_tree_1011', 0, '0', 'kesplus', '{
  "zh-CN": "只允许移动子级目录！",
  "en-US": "Only child directory can be moved!"
}', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('eff5972bf3974941b6cd394452445666', 'kesplus_tree_1012', 0, '0', 'kesplus', '{
  "zh-CN": "当前对象已被其他用户锁定,不能删除。",
  "en-US": "The current object is locked by another user and cannot be deleted."
}', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('f9ab974ad12a4784b80da1bbe5529e68', 'kesplus_tree_1013', 0, '0', 'kesplus', '{ "zh-CN" : "未知节点类型", "en-US" : "Unknown node type." }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('e41ca2310ea54cf2b00e0b0c97349ae0', 'kesplus_upgrade_1000', 0, '0', 'kesplus', '{ "zh-CN" : "非平台库，无法执行", "en-US" : "only can run in platform database" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('e973ca3a53194ecebfc5a8bccf759272', 'kesplus_user_1000', 0, '0', 'kesplus', '{ "zh-CN" : "用户名或密码错误", "en-US" : "The username or password is incorrect" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('ec18b57b4d7d42998a2915904a15d876', 'kesplus_user_1001', 0, '0', 'kesplus', '{ "zh-CN" : "用户不存在", "en-US" : "the user not exists" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('895e86a542734256857543f8fea0ae85', 'kesplus_user_1002', 0, '0', 'kesplus', '{ "zh-CN" : "用户已存在", "en-US" : "the user already exists" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('d1a0ef0af3f245f4a15a450f430b191b', 'kesplus_version_1000', 0, '0', 'kesplus', '{ "zh-CN" : "版本不能为空", "en-US" : "version cannot be null" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('d65e61d35d534a56a64ceb313629c3eb', 'kesplus_view_1001', 0, '0', 'kesplus', '{ "zh-CN" : "同一层级视图目录和视图对象名称不能重复!", "en-US" : "The view directory and view object names at the same level must be unique!" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('733f550d68dc451498b0ecaf56abcb19', 'kesplus_view_1002', 0, '0', 'kesplus', '{ "zh-CN" : "模式不能为空!", "en-US" : "The upper level must be directory!" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('bfeaeb95160c433c8715c26eab0e281e', 'kesplus_view_1003', 0, '0', 'kesplus', '{ "zh-CN" : "视图对象名称重复!", "en-US" : "The view name repeats at the current level!" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('8726e17380384011ac6497ba32282912', 'kesplus_view_1005', 0, '0', 'kesplus', '{ "zh-CN" : "含有下级菜单的目录不能修改为非目录类型!", "en-US" : "Please enter a new view name!" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('e8e8cebce2424a0eb42ba798c5934cbc', 'kesplus_view_1006', 0, '0', 'kesplus', '{ "zh-CN" : "缺少模块参数!", "en-US" : "The view name [%] already exists!" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('db7ee9e564dd410ea11d24e2c0484bee', 'kesplus_view_1007', 0, '0', 'kesplus', '{ "zh-CN" : "视图api目录ID为空!", "en-US" : "View API directory ID is empty!" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('6f5f34e3623049f0b91b40d4d9d7d12b', 'session_variable_1001', 0, '0', 'kesplus', '{ "zh-CN" : "系统变量的标识不能为空！", "en-US" : "System Variable identifier cannot be empty!" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('5bbe0c2f1c494af6a67c0f535077212a', 'kesplus_token_5010', 0, '0', 'kesplus', '{ "zh-CN" : "当前功能无操作权限，请联系管理员添加", "en-US" : "NO_PERMISSION" }', -20998);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('895e86a542734256857543f8fea0ae86', 'kesplus_user_1003', 0, '0', 'kesplus', '{ "zh-CN" : "您没有权限访问此应用或此应用未与您的账号关联", "en-US" : "you do not have permission to access this app or this app is not associated with your account " }', -20998);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('895e86a542734256857543f8fea0ae87', 'kesplus_user_1004', 0, '0', 'kesplus', '{ "zh-CN" : "用户未绑定部门", "en-US" : "The user have not bind dept " }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('b99bef8e6e2b481185bdafb3b8278716', 'kesplus_view_1004', 0, '0', 'kesplus', '{ "zh-CN" : "请先删除下级关联权限点!", "en-US" : "Delete the subordinate associated permission first!" }', -20998);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('c8628d13684f42a3bca9079bfc01851a', 'kesplus_301', 0, '1', 'kesplus', '{ "zh-CN" : "端口为空或者已被占用", "en-US" : "Port is empty or already in use" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('b78eebdb240a4699bd54c476cb4a0484', 'kesplus_send_500', 0, '1', 'kesplus', '{ "zh-CN" : "未配置平台host", "en-US" : "Platform host not configured" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('e3c317860c0a426aacab927a08773d98', 'kesplus_deploy_501', 0, '1', 'kesplus', '{ "zh-CN" : "上传到包目录失败", "en-US" : "Failed to upload to package directory" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('547d750548a94497b2c03378ac5acfbd', 'kesplus_deploy_504', 0, '1', 'kesplus', '{ "zh-CN" : "应用创建失败", "en-US" : "Application creation failed" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('1be8dc0f26a74d78af246be3a3e85445', 'kesplus_deploy_507', 0, '1', 'kesplus', '{ "zh-CN" : "安装/更新/补丁包为空", "en-US" : "Installation/update/patch package is empty" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('b77f50d021f045408a2a1ef4af1c2236', 'kesplus_deploy_508', 0, '1', 'kesplus', '{ "zh-CN" : "应用名已被使用，请重新输入！", "en-US" : "Application name already in use, please re-enter" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('3d079a2724fd419093c7f8fe6cf06c59', 'kesplus_deploy_509', 0, '1', 'kesplus', '{ "zh-CN" : "清除主库应用信息失败", "en-US" : "Failed to clear main database application information" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('64b0627655fe48738f7d26f6435dae2f', 'kesplus_deploy_510', 0, '1', 'kesplus', '{ "zh-CN" : "安装应用失败", "en-US" : "Failed to install application" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('7804341d4f9b426d838a1b5a5871b66d', 'kesplus_deploy_511', 0, '1', 'kesplus', '{ "zh-CN" : "更新应用失败", "en-US" : "Failed to update application" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('c317afd06762422ea144296d63772650', 'kesplus_deploy_512', 0, '1', 'kesplus', '{ "zh-CN" : "解析安装包meta文件为空", "en-US" : "Parsed installation package meta file is empty" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('0a35944d284841a8a89f9a08f3923b3e', 'P0002', 1, '0', 'kesplus', '{ "zh-CN" : "未找到数据", "en-US" : "KES error:no_data_found" }', -20997);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('af54e134ed6c43d0b57263e57aebe1a4', 'kesplus_deploy_513', 0, '1', 'kesplus', '{ "zh-CN" : "解析安装包meta文件AppCode为空", "en-US" : "Parsed installation package meta file appCode is empty" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('f6f3d66220724bf5a4e238cce83c8675', 'kesplus_deploy_518', 0, '1', 'kesplus', '{ "zh-CN" : "安装包部署-数据库已存在", "en-US" : "Installation package deployment, database already exists" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('72fab3f79ad1447ab40b0e4279bf57a9', 'kesplus_deploy_519', 0, '1', 'kesplus', '{ "zh-CN" : "更新/补丁包部署-数据库不存在", "en-US" : "Update/patch package deployment, database does not exist" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('038ac1ee275f4d3eade44e074fb96c8c', 'kesplus_deploy_520', 0, '1', 'kesplus', '{ "zh-CN" : "安装/更新/补丁包 meta文件解密失败", "en-US" : "Failed to decrypt installation/update/patch package meta file" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('6d29f34dddd243d3bd59d40e2535da35', 'kesplus_deploy_521', 0, '1', 'kesplus', '{ "zh-CN" : "安装包部署，应用编码已存在，请重新输入应用编码", "en-US" : "Installation package deployment, application code already exists, please re-enter" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('82684c0f4f9c4ac8a1709af67c171b50', 'kesplus_deploy_522', 0, '1', 'kesplus', '{ "zh-CN" : "更新包/补丁包部署，应用AppCode不存在", "en-US" : "Update/patch package deployment, application appCode does not exist" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('a54e149e597746a78dd3bf7b2244ed70', 'kesplus_deploy_523', 0, '1', 'kesplus', '{ "zh-CN" : "应用路由服务器信息为空", "en-US" : "Application routing service information is empty" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('c6646d9610e5476085f952e5bcd5dc5b', 'kesplus_deploy_524', 0, '1', 'kesplus', '{ "zh-CN" : "应用构建信息为空", "en-US" : "Application build information is empty" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('cbd02ae38b90411194385959c99500a0', 'kesplus_deploy_525', 0, '1', 'kesplus', '{ "zh-CN" : "安装包/更新包/补丁包校验失败", "en-US" : "Failed to verify installation/update/patch package" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('a85f8899f1f2468587962379898f86e8', 'kesplus_deploy_527', 0, '1', 'kesplus', '{ "zh-CN" : "安装包部署，应用名称已存在，请重新输入应用名称", "en-US" : "Installation package deployment, application name already exists, please re-enter" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('670d5e35c93445fe8fb0cd4527358dec', 'kesplus_deploy_528', 0, '1', 'kesplus', '{ "zh-CN" : "安装包部署，更新服务器信息失败", "en-US" : "Installation package deployment, failed to update server information" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('ddaa93ea030c413f95d9ceaa6260a490', 'kesplus_deploy_529', 0, '1', 'kesplus', '{ "zh-CN" : "安装包部署，更新路由信息失败", "en-US" : "Installation package deployment, failed to update routing informatio" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('a6e955883b0f4612b0070f05e897a817', 'kesplus_deploy_530', 0, '1', 'kesplus', '{ "zh-CN" : "dist包不存在", "en-US" : "dist package does not exist" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('dab3af71ddcc415b9939286e8aa51c8c', 'kesplus_deploy_531', 0, '1', 'kesplus', '{ "zh-CN" : "dist包下载失败", "en-US" : "Failed to download dist package" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('22b75b95378e441ea7e59075f2aeeed1', 'kesplus_deploy_532', 0, '1', 'kesplus', '{ "zh-CN" : "目标服务不存在或无法访问", "en-US" : "Target service does not exist or is inaccessible" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('ee5c017437c84119a6102bcb647e9f6d', 'kesplus_build_503', 0, '1', 'kesplus', '{ "zh-CN" : "初始化文件异常，请使用sql文件，或者sql文件集合的zip压缩包", "en-US" : "Initialization file error, please use an SQL file or a zip archive of SQL files" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('1f83944acd3a4c24ad39bf4b8addcc76', 'kesplus_param_not_null', 0, '0', 'kesplus', '{ "zh-CN" : "参数[%]不能为空", "en-US" : "param[%] cannotbe null" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('1f83944acd3ccc24ad39bf4b8addcc76', 'kesplus_table_not_exist', 0, '0', 'kesplus', '{ "zh-CN" : "表[%]不存在", "en-US" : "table[%] does not exist" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('1f83944acd3ccc24aaa9bf4b8addcc76', 'kesplus_member_disabled', 0, '0', 'kesplus', '{ "zh-CN" : "当前用户已被禁用", "en-US" : "the current user was disabled to login" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('1f83944acddddc24aaa9bf4b8addcc76', 'kesplus_param_not_match', 0, '0', 'kesplus', '{ "zh-CN" : "参数[%]中含有非法字符", "en-US" : "the params [%] does not match the rules" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('1f83944acddddc24aaa9bbbb8addcc76', 'kesplus_param_not_define', 0, '0', 'kesplus', '{ "zh-CN" : "未定义的参数[%]", "en-US" : "the params[%] does not define" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('1f83944aefeddc24aaa9bbbb8addcc76', 'kesplus_cannot_delete_self', 0, '0', 'kesplus', '{ "zh-CN" : "不允许删除自己", "en-US" : "you cannot delete yourself" }', -20999);
INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('72fab3f79ad1447ab40brt5879bf57a9', 'kesplus_exception_typecode_error', 0, '0', 'kesplus', '{ "zh-CN" : "异常分类编码错误,必须在-20900到-20000之间", "en-US" : "The error typecode must be between -20900 and -20000" }', -20999);

INSERT INTO kesplus_platform.kesplus_sys_i18n
("id", "code", "db_error", "success", "app_module", "msg", "type_code")
VALUES('1f83944acd3ccc24ad39bf4b8dddcc76', 'kesplus_view_not_exist', 0, '0', 'kesplus', '{ "zh-CN" : "视图[%]不存在", "en-US" : "view [%] does not exist" }', -20999);